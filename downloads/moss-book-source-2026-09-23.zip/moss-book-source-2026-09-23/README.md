# Rebuild the Moss web book — 2026-09-23

This is the editable source edition of [Moss — A Small World, Understood](https://nicholashazen.github.io/moss/).
Open `book/src/index.md` to read, or edit the Markdown in `book/src/chapters`.
The lab code and styles live in `book/theme`; publishing helpers and their tests
live in `book/scripts`. No editorial or collaboration records are included.

Run the commands below from the extracted workspace root, the directory with
`Cargo.toml`. It contains the project's exact source and lockfile, plus only the
canonical references and directly cited documents needed to rebuild this book.
Those copied documents are build/reference inputs; this is not the complete Moss
documentation tree, and their own links are not recursively packaged.

## Install the publishing tool once

Use a Unix shell, Python **3.11 or later** for the publishing helpers, and Rust
through [rustup](https://rust-lang.github.io/rustup/installation/index.html).
Node is needed for the lab tests. From this extracted workspace:

```sh
rustup toolchain install 1.93.1 --component rustfmt --component clippy --target wasm32-unknown-unknown
scripts/with-toolchain.sh cargo install mdbook --version 0.5.3 --locked --root .tools/mdbook-0.5.3
```

The wrapper checks that local mdBook version. Its installation and the generated
site are deliberately absent from the archive. Tool installation needs network
access and the platform's native compiler/linker toolchain.

## Build, check and read

```sh
sh book/scripts/book.sh build
python3 -B book/scripts/check_book.py
python3 -B -m unittest discover -s book/scripts -p 'test_*.py'
node --test book/scripts/test_*lab*.cjs
sh book/scripts/book.sh serve
```

The fixed preview opens at http://127.0.0.1:8090/moss/ . Rebuild after edits,
then reload the browser. `book/_site` holds the static publication files;
`book/artifacts` holds the two reproducible download archives and checksums.
`package_starter.py` builds the reader's smaller coding workspace; the edition
packager builds this editable source download. Neither invokes a compiler or
changes the simulation. Copying a download into `_site` must follow mdBook's
build because mdBook clears the old output first.

If your ZIP extraction tool did not preserve executable modes, restore the
shell wrappers once with `chmod +x scripts/check.sh scripts/with-toolchain.sh`.
The archive manifest records normalized modes and exact per-file SHA-256 hashes.
The generator uses sorted entries and fixed ZIP metadata so the same source
bytes produce the same archive; no current date or machine path is embedded.

## The simulation checkpoint is still an exercise

The Rust source is a working-tree snapshot based on repository checkpoint
`83a72a5abd46339e5448076fc183bfe33cd54029`, including local modifications. It is not a
clean archive of that commit. `EDITION-MANIFEST.json` names every other included
file and its hash. The public repository is https://github.com/NicholasHazen/moss .

Movement remains unfinished and unscheduled. Read the book's setup page for the
application tool versions, green bootstrap/maintenance test command and the
deliberately red movement checkpoint. Full workspace tests stop at that exercise.
Worked-reference commands execute in temporary copies; they do not install later
biological rules in this source. Book build tests and simulation checks establish
different facts.

This package does not claim a fresh installation on every operating system.
The reading edition records what was actually verified and what remains untested.
