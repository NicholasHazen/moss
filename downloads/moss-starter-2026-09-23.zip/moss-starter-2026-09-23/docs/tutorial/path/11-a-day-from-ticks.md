# Extracted worked reference: runnable: session-11

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/11-a-day-from-ticks.md`.
Original source SHA-256: `89ea4482b46800894759f2bcd4e0dbf87f3f0a9bc0ba21b132d583341b3affb6`.

<!-- runnable: session-11 -->
```rust
const TICKS_PER_DAY: u64 = 240;

fn is_daylight(tick: u64) -> bool {
    tick % TICKS_PER_DAY < TICKS_PER_DAY / 2
}

#[test]
fn session_11_daylight_changes_at_exact_tick_boundaries() {
    assert!(is_daylight(0));
    assert!(is_daylight(119));
    assert!(!is_daylight(120));
    assert!(!is_daylight(239));
    assert!(is_daylight(240));
    assert!(is_daylight(359));
    assert!(!is_daylight(360));

    let completed_tick = 119_u64;
    let executing_tick = completed_tick.checked_add(1).expect("tick overflow");
    assert_eq!(executing_tick, 120);
    assert!(!is_daylight(executing_tick));
    assert!(is_daylight(completed_tick));

    assert_eq!((1..120).filter(|tick| is_daylight(*tick)).count(), 119);
    assert_eq!((240..360).filter(|tick| is_daylight(*tick)).count(), 120);
}
```
