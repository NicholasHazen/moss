# Extracted worked reference: runnable: session-01

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/01-bounded-meal.md`.
Original source SHA-256: `fbb9583ffd0e35cc2ff1dbdd52fb90a40baed0fadf25db0115d0c2bed84a4523`.

<!-- runnable: session-01 -->
```rust
use moss_sim::{Energy, FoodPatch};

fn eat_from_patch(energy: &mut Energy, patch: &mut FoodPatch, bite_limit: u32) -> u32 {
    let room = energy.capacity.saturating_sub(energy.reserve);
    let consumed = room.min(patch.biomass).min(bite_limit);
    energy.reserve = energy
        .reserve
        .checked_add(consumed)
        .expect("meal energy overflow");
    patch.biomass -= consumed;
    consumed
}

#[test]
fn session_01_a_meal_changes_both_participants() {
    let mut fern = Energy {
        reserve: 98,
        capacity: 100,
    };
    let mut meadow = FoodPatch {
        name: "Meadow",
        biomass: 5,
    };

    assert_eq!(eat_from_patch(&mut fern, &mut meadow, 4), 2);
    assert_eq!(fern.reserve, 100);
    assert_eq!(meadow.biomass, 3);
    assert_eq!(eat_from_patch(&mut fern, &mut meadow, 4), 0);
    assert_eq!(meadow.biomass, 3);

    fern.reserve = 0;
    assert_eq!(eat_from_patch(&mut fern, &mut meadow, 0), 0);
    assert_eq!(fern.reserve, 0);
    assert_eq!(meadow.biomass, 3);

    assert_eq!(eat_from_patch(&mut fern, &mut meadow, 2), 2);
    assert_eq!(fern.reserve, 2);
    assert_eq!(meadow.biomass, 1);

    assert_eq!(eat_from_patch(&mut fern, &mut meadow, 4), 1);
    assert_eq!(fern.reserve, 3);
    assert_eq!(meadow.biomass, 0);
    assert_eq!(eat_from_patch(&mut fern, &mut meadow, 4), 0);
    assert_eq!(fern.reserve, 3);
    assert_eq!(meadow.biomass, 0);
}
```
