# Extracted worked reference: runnable: session-15

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/15-read-a-scarcity-run.md`.
Original source SHA-256: `d98e6c17bf7e8445e3b84d9f5552da72b9396230813c3317690a3f7e7db8b612`.

<!-- runnable: session-15 -->
```rust
struct PopulationSample {
    seeded: u32,
    births: u32,
    deaths: u32,
    living: u32,
}

fn population_account_agrees(sample: &PopulationSample) -> bool {
    sample
        .seeded
        .checked_add(sample.births)
        .and_then(|total| total.checked_sub(sample.deaths))
        == Some(sample.living)
}

#[test]
fn session_15_population_account_rejects_missing_or_impossible_deaths() {
    for (deaths, living) in [(0, 6), (1, 5), (3, 3), (6, 0)] {
        let sample = PopulationSample {
            seeded: 6,
            births: 0,
            deaths,
            living,
        };
        assert!(population_account_agrees(&sample));
    }
    let missing_death = PopulationSample {
        seeded: 6,
        births: 0,
        deaths: 1,
        living: 3,
    };
    assert!(!population_account_agrees(&missing_death));
    let impossible = PopulationSample {
        seeded: 6,
        births: 0,
        deaths: 7,
        living: 0,
    };
    assert!(!population_account_agrees(&impossible));

    let overflowing = PopulationSample {
        seeded: u32::MAX,
        births: 1,
        deaths: 0,
        living: 0,
    };
    assert!(!population_account_agrees(&overflowing));
}
```
