# Extracted worked reference: runnable: session-07

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/07-querying-costs.md`.
Original source SHA-256: `52bb4f7e48937117ed51a011e4f09593feba991b23764e5e807725f646b785ae`.

<!-- runnable: session-07 -->
```rust
use bevy_ecs::{prelude::*, schedule::ExecutorKind};
use moss_sim::{Creature, Energy, Species};

#[derive(Component)]
struct AnimalEnergyCosts {
    maintenance_units_per_tick: u32,
}

fn spend_energy(mut animals: Query<(&AnimalEnergyCosts, &mut Energy), With<Creature>>) {
    for (costs, mut energy) in &mut animals {
        energy.reserve = energy
            .reserve
            .saturating_sub(costs.maintenance_units_per_tick);
    }
}

#[test]
fn session_07_same_species_can_have_different_costs() {
    let mut world = World::new();
    let first = world
        .spawn((
            Creature { name: "Fern" },
            Species::Hare,
            Energy {
                reserve: 60,
                capacity: 100,
            },
            AnimalEnergyCosts {
                maintenance_units_per_tick: 1,
            },
        ))
        .id();
    let second = world
        .spawn((
            Creature {
                name: "another hare",
            },
            Species::Hare,
            Energy {
                reserve: 60,
                capacity: 100,
            },
            AnimalEnergyCosts {
                maintenance_units_per_tick: 2,
            },
        ))
        .id();
    let grass = world.spawn(Species::Grass).id();

    let animal_count = world
        .query_filtered::<Entity, With<Creature>>()
        .iter(&world)
        .count();
    let cost_count = world
        .query_filtered::<&AnimalEnergyCosts, With<Creature>>()
        .iter(&world)
        .count();
    assert_eq!(animal_count, 2);
    assert_eq!(cost_count, 2);
    assert!(world.get::<AnimalEnergyCosts>(grass).is_none());

    let mut schedule = Schedule::default();
    schedule.set_executor_kind(ExecutorKind::SingleThreaded);
    schedule.add_systems(spend_energy);
    for _ in 0..3 {
        schedule.run(&mut world);
    }
    assert_eq!(world.get::<Energy>(first).unwrap().reserve, 57);
    assert_eq!(world.get::<Energy>(second).unwrap().reserve, 54);

    world.get_mut::<Energy>(second).unwrap().reserve = 1;
    schedule.run(&mut world);
    assert_eq!(world.get::<Energy>(second).unwrap().reserve, 0);
    assert!(world.get::<Creature>(second).is_some());
}

#[test]
fn session_07_only_matching_entities_pay() {
    let mut world = World::new();
    let energy = Energy {
        reserve: 60,
        capacity: 100,
    };
    let eligible = world
        .spawn((
            Creature { name: "eligible" },
            energy,
            AnimalEnergyCosts {
                maintenance_units_per_tick: 1,
            },
        ))
        .id();
    let missing_cost = world.spawn((Creature { name: "no cost" }, energy)).id();
    let not_an_animal = world
        .spawn((
            energy,
            AnimalEnergyCosts {
                maintenance_units_per_tick: 1,
            },
        ))
        .id();

    let mut schedule = Schedule::default();
    schedule.set_executor_kind(ExecutorKind::SingleThreaded);
    schedule.add_systems(spend_energy);
    schedule.run(&mut world);

    assert_eq!(world.get::<Energy>(eligible).unwrap().reserve, 59);
    assert_eq!(world.get::<Energy>(missing_cost).unwrap().reserve, 60);
    assert_eq!(world.get::<Energy>(not_an_animal).unwrap().reserve, 60);
}
```
