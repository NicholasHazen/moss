# Extracted worked reference: runnable: session-08

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/08-a-fair-comparison.md`.
Original source SHA-256: `e54921fa8b336bb3519bd5dffe6635f1cc1c16a7add055a6efdb9f3cdc314b46`.

<!-- runnable: session-08 -->
```rust
#[derive(Debug, PartialEq, Eq)]
struct Account {
    reserve: u32,
    maintenance_spent: u32,
    travel_spent: u32,
}

fn account_trace(maintenance_units_per_tick: u32, accepted_cells: &[u32]) -> Account {
    let mut result = Account {
        reserve: 60,
        maintenance_spent: 0,
        travel_spent: 0,
    };
    for &distance in accepted_cells {
        let actual_maintenance = result.reserve.min(maintenance_units_per_tick);
        result.reserve -= actual_maintenance;
        result.maintenance_spent = result
            .maintenance_spent
            .checked_add(actual_maintenance)
            .expect("maintenance total overflow");
        let travel = distance.checked_mul(2).expect("travel cost overflow");
        assert!(
            travel <= result.reserve,
            "trace contains an unaffordable step"
        );
        result.reserve -= travel;
        result.travel_spent = result
            .travel_spent
            .checked_add(travel)
            .expect("travel total overflow");
    }
    result
}

#[test]
fn session_08_equal_journeys_reveal_the_upkeep_difference() {
    let fern = account_trace(1, &[1, 1, 1]);
    let other = account_trace(2, &[1, 1, 1]);
    assert_eq!(
        fern,
        Account {
            reserve: 51,
            maintenance_spent: 3,
            travel_spent: 6
        }
    );
    assert_eq!(
        other,
        Account {
            reserve: 48,
            maintenance_spent: 6,
            travel_spent: 6
        }
    );
    assert_eq!(fern.reserve - other.reserve, 3);
    assert_eq!(
        fern.reserve + fern.maintenance_spent + fern.travel_spent,
        60
    );
    assert_eq!(
        other.reserve + other.maintenance_spent + other.travel_spent,
        60
    );
    assert_eq!(account_trace(1, &[0, 0, 0]).reserve, 57);
}
```
