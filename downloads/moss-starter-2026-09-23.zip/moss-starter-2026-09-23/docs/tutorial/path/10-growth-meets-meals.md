# Extracted worked reference: runnable: session-10

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/10-growth-meets-meals.md`.
Original source SHA-256: `5b2cf76446cc129387e50349f21f92df425925cbfc44e22aab8694d82c84159d`.

<!-- runnable: session-10 -->
```rust
use moss_sim::{Energy, FoodPatch};

fn grow(patch: &mut FoodPatch, capacity: u32, rate: u32) -> u32 {
    assert!(patch.biomass <= capacity);
    let actual = rate.min(capacity - patch.biomass);
    patch.biomass = patch.biomass.checked_add(actual).expect("biomass overflow");
    actual
}

fn eat(energy: &mut Energy, patch: &mut FoodPatch, bite: u32) -> u32 {
    let actual = bite
        .min(patch.biomass)
        .min(energy.capacity.saturating_sub(energy.reserve));
    energy.reserve = energy.reserve.checked_add(actual).expect("energy overflow");
    patch.biomass -= actual;
    actual
}

#[test]
fn session_10_growth_then_food_preserves_the_account() {
    let mut fern = Energy {
        reserve: 20,
        capacity: 100,
    };
    let mut meadow = FoodPatch {
        name: "Meadow",
        biomass: 0,
    };
    assert_eq!(grow(&mut meadow, 100, 1), 1);
    assert_eq!(eat(&mut fern, &mut meadow, 4), 1);
    assert_eq!((fern.reserve, meadow.biomass), (21, 0));

    fern.reserve = 20;
    meadow.biomass = 100;
    assert_eq!(grow(&mut meadow, 100, 1), 0);
    assert_eq!(eat(&mut fern, &mut meadow, 4), 4);
    assert_eq!((fern.reserve, meadow.biomass), (24, 96));
    assert_eq!(fern.reserve + meadow.biomass, 120);
}
```
