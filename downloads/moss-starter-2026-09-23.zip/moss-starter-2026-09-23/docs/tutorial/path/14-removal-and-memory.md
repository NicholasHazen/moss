# Extracted worked reference: runnable: session-14

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/14-removal-and-memory.md`.
Original source SHA-256: `0965db3b44c8c82ff29814c371d9e34b044abc50d2ad6b405e69cccdb5232b98`.

<!-- runnable: session-14 -->
```rust
use bevy_ecs::prelude::*;
use moss_sim::{Creature, Energy, SimId};

fn remove_starved(world: &mut World) -> Vec<SimId> {
    // Phase 1: inspect components and copy only the handles needed afterward.
    let mut terminal: Vec<_> = {
        let mut query = world.query_filtered::<(Entity, &SimId, &Energy), With<Creature>>();
        query
            .iter(world)
            .filter(|(_, _, energy)| energy.reserve == 0)
            .map(|(entity, id, _)| (entity, *id))
            .collect()
    };
    terminal.sort_by_key(|(_, id)| *id);

    // Phase 2: no query borrow remains, so changing the world's structure is safe.
    let mut removed = Vec::new();
    for (entity, id) in terminal {
        if world.despawn(entity) {
            removed.push(id);
        }
    }
    removed
}

#[test]
fn session_14_removal_reports_each_terminal_id_once() {
    let mut world = World::new();
    for (id, reserve) in [(2, 0), (9, 5), (1, 0)] {
        world.spawn((
            SimId(id),
            Creature { name: "test hare" },
            Energy {
                reserve,
                capacity: 100,
            },
        ));
    }
    assert_eq!(remove_starved(&mut world), vec![SimId(1), SimId(2)]);
    assert!(remove_starved(&mut world).is_empty());

    let remaining: Vec<_> = world
        .query::<(&SimId, &Energy)>()
        .iter(&world)
        .map(|(id, energy)| (*id, energy.reserve))
        .collect();
    assert_eq!(remaining, vec![(SimId(9), 5)]);
}
```
