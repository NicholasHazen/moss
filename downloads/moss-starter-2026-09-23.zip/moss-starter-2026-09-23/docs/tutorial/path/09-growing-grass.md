# Extracted worked reference: runnable: session-09

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/09-growing-grass.md`.
Original source SHA-256: `6a1430d36e40afb59e52f1de4de218e01c0848670aa321a6ee213e3349d3eebe`.

<!-- runnable: session-09 -->
```rust
use moss_sim::FoodPatch;

fn grow_biomass(patch: &mut FoodPatch, capacity: u32, requested: u32) -> u32 {
    assert!(patch.biomass <= capacity, "biomass exceeds capacity");
    let actual = requested.min(capacity - patch.biomass);
    patch.biomass = patch.biomass.checked_add(actual).expect("biomass overflow");
    actual
}

#[test]
fn session_09_growth_reports_only_what_fits() {
    let mut meadow = FoodPatch {
        name: "Meadow",
        biomass: 99,
    };
    assert_eq!(grow_biomass(&mut meadow, 100, 3), 1);
    assert_eq!(meadow.biomass, 100);
    assert_eq!(grow_biomass(&mut meadow, 100, 3), 0);
    assert_eq!(meadow.biomass, 100);

    meadow.biomass = 95;
    assert_eq!(grow_biomass(&mut meadow, 100, 3), 3);
    assert_eq!(meadow.biomass, 98);

    meadow.biomass = 0;
    assert_eq!(grow_biomass(&mut meadow, 100, 1), 1);
    assert_eq!(meadow.biomass, 1);
    assert_eq!(grow_biomass(&mut meadow, 100, 0), 0);
    assert_eq!(meadow.biomass, 1);
}
```
