# Extracted worked reference: runnable: session-05

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/05-many-individuals.md`.
Original source SHA-256: `cd6d3c06b22d52cdd30fc92457ef084358fad51b84aa9fe5a51ef00ffc5a1644`.

<!-- runnable: session-05 -->
```rust
#[derive(Debug, PartialEq)]
struct EnergySummary {
    count: usize,
    minimum: u32,
    maximum: u32,
    mean: f64,
}

fn summarize_energy(reserves: &[u32]) -> Option<EnergySummary> {
    let (&first, rest) = reserves.split_first()?;
    let mut total = u64::from(first);
    let mut minimum = first;
    let mut maximum = first;
    for &reserve in rest {
        total = total
            .checked_add(u64::from(reserve))
            .expect("population energy total overflow");
        minimum = minimum.min(reserve);
        maximum = maximum.max(reserve);
    }
    Some(EnergySummary {
        count: reserves.len(),
        minimum,
        maximum,
        mean: total as f64 / reserves.len() as f64,
    })
}

#[test]
fn session_05_a_mean_has_members_and_limits() {
    assert_eq!(
        summarize_energy(&[20, 60]),
        Some(EnergySummary {
            count: 2,
            minimum: 20,
            maximum: 60,
            mean: 40.0,
        })
    );
    assert_eq!(
        summarize_energy(&[60; 6]),
        Some(EnergySummary {
            count: 6,
            minimum: 60,
            maximum: 60,
            mean: 60.0,
        })
    );
    assert_eq!(summarize_energy(&[]), None);
    assert_eq!(summarize_energy(&[20, 21]).unwrap().mean, 20.5);
    let unequal = summarize_energy(&[0, 100]).unwrap();
    let equal = summarize_energy(&[50, 50]).unwrap();
    assert_eq!(unequal.mean, equal.mean);
    assert_eq!((unequal.minimum, unequal.maximum), (0, 100));
    assert_eq!((equal.minimum, equal.maximum), (50, 50));
}
```
