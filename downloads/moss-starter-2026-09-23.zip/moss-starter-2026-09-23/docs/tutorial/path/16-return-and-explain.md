# Extracted worked reference: runnable: session-16

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/16-return-and-explain.md`.
Original source SHA-256: `5f1db21ade3d94966a1cb2ee4885b5ce0bc0452619e2eef9210a811c40327304`.

<!-- runnable: session-16 -->
```rust
use bevy_ecs::prelude::*;
use moss_sim::{Creature, Energy, FoodTarget, Position, SimId};

#[derive(Debug, PartialEq, Eq)]
struct AnimalSnapshot {
    id: SimId,
    position: Position,
    reserve: u32,
    target: Option<SimId>,
}

fn example_world(reverse: bool) -> World {
    let mut world = World::new();
    let mut rows = [
        (SimId(1), Position { x: 10, y: 10 }, Some(SimId(3))),
        (SimId(2), Position { x: 21, y: 6 }, None),
    ];
    if reverse {
        rows.reverse();
    }
    for (id, position, target) in rows {
        let mut entity = world.spawn((
            id,
            position,
            Creature { name: "example" },
            Energy {
                reserve: 57,
                capacity: 100,
            },
        ));
        if let Some(id) = target {
            entity.insert(FoodTarget(id));
        }
    }
    world
}

fn snapshot(world: &mut World) -> Vec<AnimalSnapshot> {
    let mut animals: Vec<_> = world
        .query_filtered::<(&SimId, &Position, &Energy, Option<&FoodTarget>), With<Creature>>()
        .iter(world)
        .map(|(id, position, energy, target)| AnimalSnapshot {
            id: *id,
            position: *position,
            reserve: energy.reserve,
            target: target.map(|target| target.0),
        })
        .collect();
    animals.sort_by_key(|animal| animal.id);
    animals
}

#[test]
fn session_16_snapshots_ignore_order_but_detect_state_changes() {
    let mut first = example_world(false);
    let mut reordered = example_world(true);
    let expected = snapshot(&mut first);
    assert_eq!(expected, snapshot(&mut reordered));
    assert_eq!(
        expected,
        vec![
            AnimalSnapshot {
                id: SimId(1),
                position: Position { x: 10, y: 10 },
                reserve: 57,
                target: Some(SimId(3)),
            },
            AnimalSnapshot {
                id: SimId(2),
                position: Position { x: 21, y: 6 },
                reserve: 57,
                target: None,
            },
        ]
    );

    let fern = reordered
        .query_filtered::<Entity, With<FoodTarget>>()
        .single(&reordered)
        .unwrap();
    reordered.get_mut::<Energy>(fern).unwrap().reserve = 56;
    assert_ne!(expected, snapshot(&mut reordered));

    reordered.get_mut::<Energy>(fern).unwrap().reserve = 57;
    reordered.get_mut::<FoodTarget>(fern).unwrap().0 = SimId(4);
    assert_ne!(expected, snapshot(&mut reordered));
}
```
