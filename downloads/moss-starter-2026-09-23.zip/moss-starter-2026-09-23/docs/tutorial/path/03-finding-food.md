# Extracted worked reference: runnable: session-03

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/03-finding-food.md`.
Original source SHA-256: `dba210caf3d69ba323cc6b3f32c274131200d3e9d87098935c5d5e6bbcd06a8a`.

<!-- runnable: session-03 -->
```rust
use moss_sim::{Position, SimId};

fn nearest_food(
    origin: Position,
    patches: &[(SimId, Position, u32)],
    radius_cells: u32,
) -> Option<SimId> {
    let mut best: Option<(u32, SimId)> = None;
    for &(id, position, biomass) in patches {
        if biomass == 0 {
            continue;
        }
        let distance = origin
            .x
            .abs_diff(position.x)
            .checked_add(origin.y.abs_diff(position.y))
            .expect("grid distance overflow");
        if distance > radius_cells {
            continue;
        }
        let candidate = (distance, id);
        let improves_choice = match best {
            None => true,
            Some(previous) => candidate < previous,
        };
        if improves_choice {
            best = Some(candidate);
        }
    }
    best.map(|(_, id)| id)
}

#[test]
fn session_03_choices_survive_reordered_observations() {
    let origin = Position { x: 2, y: 2 };
    let mut patches = vec![
        (SimId(9), Position { x: 1, y: 2 }, 80),
        (SimId(4), Position { x: 3, y: 2 }, 80),
        (SimId(3), Position { x: 4, y: 2 }, 80),
        (SimId(1), origin, 0),
        (SimId(2), Position { x: 7, y: 2 }, 80),
    ];
    assert_eq!(nearest_food(origin, &patches, 2), Some(SimId(4)));
    patches.reverse();
    assert_eq!(nearest_food(origin, &patches, 2), Some(SimId(4)));
    assert_eq!(nearest_food(origin, &patches, 0), None);
    assert_eq!(nearest_food(origin, &[], 2), None);
    assert_eq!(
        nearest_food(origin, &[(SimId(8), origin, 1)], 0),
        Some(SimId(8))
    );

    let diagonal_case = [
        (SimId(8), Position { x: 9, y: 8 }, 80),
        (SimId(9), Position { x: 10, y: 6 }, 80),
    ];
    assert_eq!(
        nearest_food(Position { x: 6, y: 6 }, &diagonal_case, 4),
        Some(SimId(9))
    );
}
```
