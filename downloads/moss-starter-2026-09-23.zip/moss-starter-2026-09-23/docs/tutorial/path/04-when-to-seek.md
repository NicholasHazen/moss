# Extracted worked reference: runnable: session-04

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/04-when-to-seek.md`.
Original source SHA-256: `c50126bf6f7530b3de3221ecd89a7d4870f1f3132f4e6db49a0f51e0c69b441e`.

<!-- runnable: session-04 -->
```rust
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ForagingState {
    Idle,
    Seeking,
}

fn next_foraging_state(previous: ForagingState, reserve: u32) -> ForagingState {
    match previous {
        ForagingState::Idle if reserve < 45 => ForagingState::Seeking,
        ForagingState::Seeking if reserve >= 75 => ForagingState::Idle,
        _ => previous,
    }
}

#[test]
fn session_04_the_middle_band_remembers_activity() {
    use ForagingState::{Idle, Seeking};

    assert_eq!(next_foraging_state(Idle, 44), Seeking);
    assert_eq!(next_foraging_state(Idle, 45), Idle);
    assert_eq!(next_foraging_state(Idle, 60), Idle);
    assert_eq!(next_foraging_state(Seeking, 60), Seeking);
    assert_eq!(next_foraging_state(Seeking, 74), Seeking);
    assert_eq!(next_foraging_state(Seeking, 75), Idle);

    let after_maintenance = 45_u32.saturating_sub(1);
    assert_eq!(next_foraging_state(Idle, after_maintenance), Seeking);
    let after_maintenance = 76_u32.saturating_sub(1);
    assert_eq!(next_foraging_state(Seeking, after_maintenance), Idle);
}
```
