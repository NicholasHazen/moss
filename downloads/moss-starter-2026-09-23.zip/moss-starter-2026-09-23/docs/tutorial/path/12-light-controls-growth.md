# Extracted worked reference: runnable: session-12

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/12-light-controls-growth.md`.
Original source SHA-256: `27e57b8e04c71f2e631d32ffd7d3ea7708583fae8dd977d18ce2f1ec9fc702ea`.

<!-- runnable: session-12 -->
```rust
use moss_sim::{Energy, FoodPatch};

fn requested_growth(daylight: bool, full_light_rate: u32) -> u32 {
    if daylight { full_light_rate } else { 0 }
}

fn produce_for_tick(patch: &mut FoodPatch, executing_tick: u64) -> u32 {
    let daylight = executing_tick % 240 < 120;
    let requested = requested_growth(daylight, 1);
    assert!(patch.biomass <= 100);
    let actual = requested.min(100 - patch.biomass);
    patch.biomass = patch.biomass.checked_add(actual).expect("biomass overflow");
    actual
}

fn eat_stored_food(energy: &mut Energy, patch: &mut FoodPatch) -> u32 {
    let eaten = 4_u32
        .min(patch.biomass)
        .min(energy.capacity.saturating_sub(energy.reserve));
    patch.biomass -= eaten;
    energy.reserve = energy.reserve.checked_add(eaten).expect("energy overflow");
    eaten
}

#[test]
fn session_12_light_changes_production_without_erasing_food() {
    assert_eq!(requested_growth(true, 3), 3);
    assert_eq!(requested_growth(false, 3), 0);
    assert_eq!(requested_growth(true, 0), 0);

    let mut meadow = FoodPatch {
        name: "Meadow",
        biomass: 98,
    };
    assert_eq!(produce_for_tick(&mut meadow, 119), 1);
    assert_eq!(meadow.biomass, 99);
    assert_eq!(produce_for_tick(&mut meadow, 120), 0);
    assert_eq!(produce_for_tick(&mut meadow, 239), 0);
    assert_eq!(meadow.biomass, 99);
    assert_eq!(produce_for_tick(&mut meadow, 240), 1);
    assert_eq!(meadow.biomass, 100);

    let mut fern = Energy {
        reserve: 20,
        capacity: 100,
    };
    let eaten = eat_stored_food(&mut fern, &mut meadow);
    assert_eq!((eaten, fern.reserve, meadow.biomass), (4, 24, 96));

    assert_eq!(produce_for_tick(&mut meadow, 241), 1);
    assert_eq!(meadow.biomass, 97);

    let mut night_food = FoodPatch {
        name: "night stock",
        biomass: 4,
    };
    fern.reserve = 20;
    assert_eq!(produce_for_tick(&mut night_food, 120), 0);
    assert_eq!(eat_stored_food(&mut fern, &mut night_food), 4);
    assert_eq!((fern.reserve, night_food.biomass), (24, 0));
}
```
