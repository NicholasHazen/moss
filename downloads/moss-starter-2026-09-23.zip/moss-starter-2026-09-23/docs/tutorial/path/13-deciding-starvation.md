# Extracted worked reference: runnable: session-13

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/13-deciding-starvation.md`.
Original source SHA-256: `78dfbf8cce712ad086b8ded5852301fcafb5040cc1a5378bf5d468230a9502d2`.

<!-- runnable: session-13 -->
```rust
use moss_sim::{Energy, FoodPatch};

fn is_starved_after_meals(energy: &Energy) -> bool {
    energy.reserve == 0
}

fn contact_tick(
    energy: &mut Energy,
    food: &mut FoodPatch,
    executing_tick: u64,
    maintenance_units_per_tick: u32,
) -> bool {
    // Reuse the preceding lessons' order: light and growth precede the meal.
    let daylight = executing_tick % 240 < 120;
    let requested_growth = if daylight { 1_u32 } else { 0 };
    assert!(food.biomass <= 100);
    let actual_growth = requested_growth.min(100 - food.biomass);
    food.biomass = food
        .biomass
        .checked_add(actual_growth)
        .expect("biomass overflow");

    energy.reserve = energy.reserve.saturating_sub(maintenance_units_per_tick);
    let eaten = 4_u32
        .min(food.biomass)
        .min(energy.capacity.saturating_sub(energy.reserve));
    food.biomass -= eaten;
    energy.reserve = energy.reserve.checked_add(eaten).expect("energy overflow");
    is_starved_after_meals(energy)
}

#[test]
fn session_13_stored_food_and_dawn_growth_can_prevent_starvation() {
    let mut fern = Energy {
        reserve: 1,
        capacity: 100,
    };
    let mut meadow = FoodPatch {
        name: "Meadow",
        biomass: 4,
    };
    assert!(!contact_tick(&mut fern, &mut meadow, 120, 1));
    assert_eq!((fern.reserve, meadow.biomass), (4, 0));

    fern.reserve = 1;
    assert!(contact_tick(&mut fern, &mut meadow, 120, 1));
    assert_eq!((fern.reserve, meadow.biomass), (0, 0));

    fern.reserve = 1;
    assert!(!contact_tick(&mut fern, &mut meadow, 240, 1));
    assert_eq!((fern.reserve, meadow.biomass), (1, 0));
    assert!(!is_starved_after_meals(&fern));

    // Start a separate trace: a requested drain of 2, with only 1 available.
    fern.reserve = 1;
    meadow.biomass = 0;
    for executing_tick in 240..360 {
        assert!(!contact_tick(&mut fern, &mut meadow, executing_tick, 2));
        assert_eq!((fern.reserve, meadow.biomass), (1, 0));
    }
    assert!(contact_tick(&mut fern, &mut meadow, 360, 2));
    assert_eq!((fern.reserve, meadow.biomass), (0, 0));
}
```
