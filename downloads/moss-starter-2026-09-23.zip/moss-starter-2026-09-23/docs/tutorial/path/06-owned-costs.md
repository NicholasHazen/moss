# Extracted worked reference: runnable: session-06

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/06-owned-costs.md`.
Original source SHA-256: `f99948d76fe401fa4f4dc879b6cc3ab84a7a25ff77c19fb65f6ef2933f0944a7`.

<!-- runnable: session-06 -->
```rust
use bevy_ecs::prelude::Component;

#[derive(Component, Clone, Copy, Debug, PartialEq, Eq)]
pub struct AnimalEnergyCosts {
    pub maintenance_units_per_tick: u32,
}

fn resolve_costs(
    species_default: AnimalEnergyCosts,
    maintenance_override: Option<u32>,
) -> AnimalEnergyCosts {
    AnimalEnergyCosts {
        maintenance_units_per_tick: maintenance_override
            .unwrap_or(species_default.maintenance_units_per_tick),
    }
}

#[test]
fn session_06_an_override_is_resolved_at_creation() {
    let mut hare_default = AnimalEnergyCosts {
        maintenance_units_per_tick: 1,
    };
    let fern = resolve_costs(hare_default, None);
    let explicit_one = resolve_costs(hare_default, Some(1));
    let other_hare = resolve_costs(hare_default, Some(2));
    let free_upkeep = resolve_costs(hare_default, Some(0));
    assert_eq!(fern.maintenance_units_per_tick, 1);
    assert_eq!(explicit_one, fern); // Equal results can have different authored inputs.
    assert_eq!(other_hare.maintenance_units_per_tick, 2);
    assert_eq!(free_upkeep.maintenance_units_per_tick, 0);

    hare_default.maintenance_units_per_tick = 9;
    assert_eq!(fern.maintenance_units_per_tick, 1);
    assert_eq!(other_hare.maintenance_units_per_tick, 2);
    assert_eq!(
        resolve_costs(hare_default, None).maintenance_units_per_tick,
        9
    );
    assert_eq!(
        resolve_costs(hare_default, Some(1)).maintenance_units_per_tick,
        1
    );
}
```
