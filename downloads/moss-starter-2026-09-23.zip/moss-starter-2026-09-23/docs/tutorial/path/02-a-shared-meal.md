# Extracted worked reference: runnable: session-02

This generated file contains only the canonical Rust example required
by the isolated reference runner. It is not the full tutorial page.
Read the lesson at https://nicholashazen.github.io/moss/.

Original source: `docs/tutorial/path/02-a-shared-meal.md`.
Original source SHA-256: `471867513aa1460424a010faab0b861d987b0ede92ad7ec4a0da13766c3cc2f4`.

<!-- runnable: session-02 -->
```rust
use moss_sim::{Energy, FoodPatch, SimId};

#[derive(Debug, PartialEq, Eq)]
struct Meal {
    eater: SimId,
    consumed: u32,
}

fn eat_from_patch(energy: &mut Energy, patch: &mut FoodPatch, bite_limit: u32) -> u32 {
    let room = energy.capacity.saturating_sub(energy.reserve);
    let consumed = room.min(patch.biomass).min(bite_limit);
    energy.reserve = energy
        .reserve
        .checked_add(consumed)
        .expect("meal energy overflow");
    patch.biomass -= consumed;
    consumed
}

fn resolve_meals(eaters: &mut [(SimId, Energy)], patch: &mut FoodPatch) -> Vec<Meal> {
    eaters.sort_by_key(|(id, _)| *id);
    let mut meals = Vec::new();
    for (id, energy) in eaters {
        let consumed = eat_from_patch(energy, patch, 4);
        if consumed > 0 {
            meals.push(Meal {
                eater: *id,
                consumed,
            });
        }
    }
    meals
}

#[test]
fn session_02_order_is_a_rule_not_an_accident() {
    for ids in [[SimId(1), SimId(7)], [SimId(7), SimId(1)]] {
        let mut eaters = ids.map(|id| {
            (
                id,
                Energy {
                    reserve: 0,
                    capacity: 100,
                },
            )
        });
        let mut patch = FoodPatch {
            name: "Meadow",
            biomass: 5,
        };
        let meals = resolve_meals(&mut eaters, &mut patch);
        assert_eq!(eaters[0].0, SimId(1));
        assert_eq!(eaters[0].1.reserve, 4);
        assert_eq!(eaters[1].0, SimId(7));
        assert_eq!(eaters[1].1.reserve, 1);
        assert_eq!(patch.biomass, 0);
        assert_eq!(
            meals,
            vec![
                Meal {
                    eater: SimId(1),
                    consumed: 4
                },
                Meal {
                    eater: SimId(7),
                    consumed: 1
                },
            ]
        );
    }

    let hungry = Energy {
        reserve: 0,
        capacity: 100,
    };
    let mut eaters = [(SimId(7), hungry), (SimId(1), hungry)];
    let mut patch = FoodPatch {
        name: "Meadow",
        biomass: 4,
    };
    let meals = resolve_meals(&mut eaters, &mut patch);
    assert_eq!(eaters[0].1.reserve, 4);
    assert_eq!(eaters[1].1.reserve, 0);
    assert_eq!(patch.biomass, 0);
    assert_eq!(
        meals,
        vec![Meal {
            eater: SimId(1),
            consumed: 4,
        }]
    );

    let mut fern = [(
        SimId(1),
        Energy {
            reserve: 33,
            capacity: 100,
        },
    )];
    let mut meadow = FoodPatch {
        name: "Meadow",
        biomass: 80,
    };
    fern[0].1.reserve = fern[0].1.reserve.saturating_sub(1); // Maintenance.
    let meals = resolve_meals(&mut fern, &mut meadow); // Already at the target.
    assert_eq!(fern[0].1.reserve, 36);
    assert_eq!(meadow.biomass, 76);
    assert_eq!(meals[0].consumed, 4);
}
```
