# Moss starter — 2026-09-23

Start with [the web book](https://nicholashazen.github.io/moss/reference/start-here.html), then open this
folder's Cargo.toml in RustRover or your editor. This is a working-tree snapshot
based on repository checkpoint `83a72a5abd46339e5448076fc183bfe33cd54029`, with local source
changes included. It is **not** a clean archive of that Git commit. The exact
contents and per-file hashes are recorded in STARTER-MANIFEST.json.

Maintenance runs. Movement is deliberately unfinished and unscheduled. Animals
remain alive at zero energy. Your first edit is the body of `move_one_cell` in
`crates/moss-sim/src/lessons.rs`. No later biological rules have been installed.

## Prepare the tools

These commands use a Unix shell on macOS or Linux. Install Rust through the
[official rustup instructions](https://rust-lang.github.io/rustup/installation/index.html)
if `rustup` is not available. macOS also needs a working Apple compiler/SDK;
Linux needs its normal native compiler/linker toolchain. Native Windows setup
has not been verified; the supplied `.sh` wrappers require a Unix-like shell.

From this extracted folder:

```sh
rustup toolchain install 1.93.1 --component rustfmt --component clippy --target wasm32-unknown-unknown
cargo +1.93.1 install trunk --version 0.21.14 --locked
cargo +1.93.1 install wasm-bindgen-cli --version 0.2.123 --locked
scripts/with-toolchain.sh cargo fetch --locked
```

The first install/build may take a while. Python 3 is needed only for the
isolated worked-reference runner. Node is needed only for the JavaScript syntax
check in `scripts/check.sh`; it is not part of the application runtime.

## Establish the green baseline

```sh
scripts/with-toolchain.sh cargo test -p moss-sim --locked --test bootstrap --test maintenance
scripts/with-toolchain.sh trunk serve --locked --release
```

The focused baseline contains five tests. When Trunk reports readiness, open
http://127.0.0.1:8080/ . Select Fern, press Step three times and inspect reserve:
the authored baseline goes from 60 to 57 while position stays unchanged. Reset
returns the starting state. These are observation instructions, not evidence
that a browser was tested on your machine. Stop the server with Ctrl-C.

## Make one affordable step

Before editing, this exact test intentionally fails at `todo!()`:

```sh
scripts/with-toolchain.sh cargo test -p moss-sim --locked --test movement movement_charges_only_an_affordable_actual_step -- --exact
```

Use Chapter 1 to replace the helper's body. A passing focused test is the first
review checkpoint. The prepared ECS movement adapter remains unscheduled;
activation and the two ignored integration tests are the next reviewed change.
Running `scripts/check.sh` or all workspace tests also reaches this intentional
failure before the exercise is complete. Do not remove its assertions.

## Run a complete reference separately

The web book's reference commands work here after `cargo fetch --locked`:

```sh
python3 docs/tutorial/authoring/check_path_examples.py --session 01
python3 docs/tutorial/authoring/check_path_examples.py
python3 docs/tutorial/authoring/check_path_examples.py --movement
```

The runner uses a separate temporary workspace and target directory, with
Cargo offline. It never replaces this starter's helper or live schedule.
Reference Markdown under `docs/tutorial/` is **extraction-only**, containing the
exact Rust fences the runner needs; it is not the full guide. Read the prose in
the web book. Some original source comments mention repository documents not
included in this deliberately small bundle.

The bundle excludes Git history, collaboration notes, editorial records, local
IDE settings and credentials. No dependency cache or compiled output is bundled.
Project development continues at https://github.com/NicholasHazen/moss .
