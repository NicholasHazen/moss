use moss_course_ecosystem::{
    CourseWorld, Daylight, EventKind, FounderTrait, GrazerSeed, PatchSeed, PopulationConfig,
    PopulationError, PopulationEventKind, Scenario, SimId, Snapshot, Stage, UpkeepTrait,
};

fn fixture(traits: [u8; 2]) -> (Scenario, PopulationConfig) {
    let founders: Vec<_> = traits
        .into_iter()
        .enumerate()
        .map(|(index, value)| FounderTrait {
            id: SimId(index as u32 + 1),
            upkeep: UpkeepTrait::new(value).unwrap(),
        })
        .collect();
    let scenario = Scenario {
        daylight: Daylight::new(4, 4).unwrap(),
        grazers: founders
            .iter()
            .map(|founder| GrazerSeed {
                id: founder.id,
                reserve_units: 5,
                capacity_units: 8,
                maintenance_units_per_tick: founder.upkeep.units(),
                meal_units_per_tick: 2,
                feeding_site: Some(SimId(100)),
            })
            .collect(),
        patches: vec![PatchSeed {
            id: SimId(100),
            biomass_units: 0,
            capacity_units: 20,
            growth_units_per_lit_tick: 6,
        }],
        history_limit: 128,
    };
    (scenario, PopulationConfig::new(founders))
}

fn stores(state: &Snapshot) -> u64 {
    state
        .grazers
        .iter()
        .map(|grazer| u64::from(grazer.reserve_units))
        .sum::<u64>()
        + state
            .patches
            .iter()
            .map(|patch| u64::from(patch.biomass_units))
            .sum::<u64>()
}

fn reserves(state: &Snapshot) -> Vec<(u32, u32)> {
    state
        .grazers
        .iter()
        .map(|grazer| (grazer.id.0, grazer.reserve_units))
        .collect()
}

#[test]
fn four_tick_trace_connects_birth_payment_newborn_turn_maturation_and_cooldown() {
    let (scenario, config) = fixture([1, 1]);
    let mut world = CourseWorld::new_population(scenario, config).unwrap();
    let expected = [
        vec![(1, 3), (2, 3), (101, 4)],
        vec![(1, 4), (2, 4), (101, 5)],
        vec![(1, 5), (2, 5), (101, 6)],
        vec![(1, 3), (2, 3), (101, 7), (102, 4)],
    ];
    for (index, reserve) in expected.into_iter().enumerate() {
        world.step();
        let state = world.snapshot();
        let population = world.population_snapshot().unwrap();
        assert_eq!(state.tick, index as u64 + 1);
        assert_eq!(reserves(&state), reserve);
        assert_eq!(state.patches[0].biomass_units, 2);
        let child = population
            .individuals
            .iter()
            .find(|individual| individual.id == SimId(101))
            .unwrap();
        assert_eq!(child.first_eligible_tick, 2);
        assert_eq!(child.matures_at_tick, Some(3));
        assert_eq!(
            child.stage,
            if index < 2 {
                Stage::Juvenile
            } else {
                Stage::Adult
            }
        );
        assert_eq!(child.origin.unwrap().parents, [SimId(1), SimId(2)]);
        assert_eq!(state.grazers[2].feeding_site, Some(SimId(100)));
        assert_eq!(population.totals.births, if index == 3 { 2 } else { 1 });
    }
    let population = world.population_snapshot().unwrap();
    assert_eq!(population.history.births_between(1, 4), Some(2));
    assert_eq!(
        population
            .history
            .events
            .iter()
            .filter(|event| matches!(event.kind, PopulationEventKind::Matured { .. }))
            .count(),
        1
    );
    assert_eq!(population.ledger.transferred_units, 4);
    assert_eq!(population.ledger.dissipated_units, 2);
}

#[test]
fn inherited_trait_changes_actual_next_tick_upkeep_and_retains_a_dead_parent_link() {
    let (mut scenario, mut config) = fixture([1, 3]);
    for seed in &mut scenario.grazers {
        seed.reserve_units = 8;
        seed.meal_units_per_tick = 0;
    }
    scenario.patches[0].growth_units_per_lit_tick = 0;
    config.child_meal_units_per_tick = 0;
    config.mutation_cycle = vec![1];
    let mut world = CourseWorld::new_population(scenario, config).unwrap();
    world.step();
    assert_eq!(reserves(&world.snapshot()), vec![(1, 4), (2, 2), (101, 4)]);
    world.step();
    let state = world.snapshot();
    let population = world.population_snapshot().unwrap();
    assert_eq!(reserves(&state), vec![(1, 3), (101, 2)]);
    let child = population
        .individuals
        .iter()
        .find(|individual| individual.id == SimId(101))
        .unwrap();
    let origin = child.origin.unwrap();
    assert_eq!(
        (
            origin.donor,
            origin.inherited.value(),
            origin.proposed_delta,
            origin.applied_delta
        ),
        (SimId(1), 1, 1, 1)
    );
    assert_eq!(child.upkeep.value(), 2);
    assert_eq!(state.grazers[1].maintenance_units_per_tick, 2);
    assert!(state.history.events.iter().any(|event| event.tick == 2
        && event.kind
            == EventKind::Maintenance {
                grazer: SimId(101),
                units: 2
            }));
    assert_eq!(population.totals.starvations, 1);
    assert_eq!(origin.parents, [SimId(1), SimId(2)]);
}

#[test]
fn deterministic_donors_and_clamped_mutations_retain_proposed_and_applied_delta() {
    let (mut scenario, mut config) = fixture([1, 3]);
    for seed in &mut scenario.grazers {
        seed.reserve_units = 20;
        seed.capacity_units = 20;
        seed.meal_units_per_tick = 6;
    }
    scenario.patches[0].capacity_units = 100;
    scenario.patches[0].growth_units_per_lit_tick = 12;
    config.mutation_cycle = vec![-1, 1];
    let mut world = CourseWorld::new_population(scenario, config).unwrap();
    for _ in 0..4 {
        world.step();
    }
    let population = world.population_snapshot().unwrap();
    let first = population
        .individuals
        .iter()
        .find(|individual| individual.id == SimId(101))
        .unwrap()
        .origin
        .unwrap();
    let second = population
        .individuals
        .iter()
        .find(|individual| individual.id == SimId(102))
        .unwrap()
        .origin
        .unwrap();
    assert_eq!(
        (
            first.birth_ordinal,
            first.donor,
            first.inherited.value(),
            first.proposed_delta,
            first.applied_delta,
            first.child_trait.value()
        ),
        (0, SimId(1), 1, -1, 0, 1)
    );
    assert_eq!(
        (
            second.birth_ordinal,
            second.donor,
            second.inherited.value(),
            second.proposed_delta,
            second.applied_delta,
            second.child_trait.value()
        ),
        (1, SimId(2), 3, 1, 0, 3)
    );
}

#[test]
fn reaching_maturity_allows_birth_without_inheriting_parental_cooldown() {
    let (mut scenario, mut config) = fixture([1, 1]);
    let mut third = scenario.grazers[0].clone();
    third.id = SimId(3);
    scenario.grazers.push(third);
    config.founders.push(FounderTrait {
        id: SimId(3),
        upkeep: UpkeepTrait::new(1).unwrap(),
    });
    config.cooldown_ticks = 10;
    scenario.patches[0].capacity_units = 32;
    scenario.patches[0].growth_units_per_lit_tick = 8;
    let mut world = CourseWorld::new_population(scenario, config).unwrap();
    world.step();
    world.step();
    assert_eq!(world.population_snapshot().unwrap().totals.births, 1);
    world.step();
    let population = world.population_snapshot().unwrap();
    assert_eq!(population.totals.births, 2);
    let second = population
        .individuals
        .iter()
        .find(|individual| individual.id == SimId(102))
        .unwrap()
        .origin
        .unwrap();
    assert_eq!(second.parents, [SimId(3), SimId(101)]);
    assert_eq!(second.birth_tick, 3);
    assert_eq!(population.individuals[0].next_birth_tick, 11);
}

#[test]
fn missing_nonpatch_and_absent_sites_cannot_create_births_but_empty_real_patch_can() {
    for contact in [None, Some(SimId(999)), Some(SimId(1)), Some(SimId(100))] {
        let (mut scenario, config) = fixture([1, 1]);
        for seed in &mut scenario.grazers {
            seed.reserve_units = 8;
            seed.meal_units_per_tick = 0;
            seed.feeding_site = contact;
        }
        scenario.patches[0].growth_units_per_lit_tick = 0;
        let mut world = CourseWorld::new_population(scenario, config).unwrap();
        world.step();
        let state = world.snapshot();
        let population = world.population_snapshot().unwrap();
        if contact == Some(SimId(100)) {
            assert_eq!(reserves(&state), vec![(1, 4), (2, 4), (101, 4)]);
            assert_eq!(state.grazers[2].feeding_site, contact);
            assert_eq!(population.totals.births, 1);
        } else {
            assert_eq!(reserves(&state), vec![(1, 7), (2, 7)]);
            assert_eq!(population.next_child_id, Some(SimId(101)));
            assert_eq!(population.next_birth_ordinal, 0);
            assert!(population.history.events.is_empty());
        }
    }
}

fn four_founders(cap: usize) -> (Scenario, PopulationConfig) {
    let (mut scenario, mut config) = fixture([1, 1]);
    for id in [3, 4] {
        let mut seed = scenario.grazers[0].clone();
        seed.id = SimId(id);
        scenario.grazers.push(seed);
        config.founders.push(FounderTrait {
            id: SimId(id),
            upkeep: UpkeepTrait::new(1).unwrap(),
        });
    }
    for seed in &mut scenario.grazers {
        seed.meal_units_per_tick = 0;
    }
    scenario.patches[0].growth_units_per_lit_tick = 0;
    config.max_living = cap;
    (scenario, config)
}

#[test]
fn pending_birth_reserves_the_only_slot_before_another_pair_is_checked() {
    let (scenario, config) = four_founders(5);
    let mut world = CourseWorld::new_population(scenario, config).unwrap();
    world.step();
    let state = world.snapshot();
    let population = world.population_snapshot().unwrap();
    assert_eq!(
        reserves(&state),
        vec![(1, 1), (2, 1), (3, 4), (4, 4), (101, 4)]
    );
    assert_eq!(population.living, 5);
    assert_eq!(population.ledger.capacity_blocked_pairs, 1);
    assert_eq!(population.totals.capacity_blocked_ticks, 1);
    assert_eq!(population.totals.births, 1);
    assert_eq!(population.next_child_id, Some(SimId(102)));
}

#[test]
fn capacity_counts_denied_eligible_pairs_and_only_one_blocked_tick() {
    let (scenario, config) = four_founders(4);
    let mut world = CourseWorld::new_population(scenario, config).unwrap();
    world.step();
    let first = world.population_snapshot().unwrap();
    assert_eq!(
        (
            first.ledger.capacity_blocked_pairs,
            first.totals.capacity_blocked_pairs,
            first.totals.capacity_blocked_ticks
        ),
        (2, 2, 1)
    );
    assert_eq!(first.next_birth_ordinal, 0);
    assert_eq!(first.next_child_id, Some(SimId(101)));
    assert!(first.history.events.is_empty());
    world.step(); // Still full, but parents can no longer afford a birth.
    let second = world.population_snapshot().unwrap();
    assert_eq!(second.living, 4);
    assert_eq!(
        (
            second.ledger.capacity_blocked_pairs,
            second.totals.capacity_blocked_pairs,
            second.totals.capacity_blocked_ticks
        ),
        (0, 2, 1)
    );
}

#[test]
fn starvation_releases_a_slot_and_excludes_the_dead_parent_before_birth() {
    let (mut scenario, mut config) = four_founders(4);
    scenario.grazers[3].reserve_units = 1;
    config.history_limit = 0;
    scenario.history_limit = 0;
    let mut world = CourseWorld::new_population(scenario, config).unwrap();
    world.step();
    let state = world.snapshot();
    let population = world.population_snapshot().unwrap();
    assert_eq!(reserves(&state), vec![(1, 1), (2, 1), (3, 4), (101, 4)]);
    assert_eq!(
        (
            population.totals.initial_founders,
            population.totals.births,
            population.totals.starvations,
            population.living
        ),
        (4, 1, 1, 4)
    );
    assert_eq!(state.history.starvations_between(1, 1), None);
    assert_eq!(population.history.births_between(1, 1), None);
    assert_eq!(
        population.individuals[3].origin.unwrap().parents,
        [SimId(1), SimId(2)]
    );
}

#[test]
fn population_history_eviction_marks_partial_ticks_unknown_without_changing_census() {
    let (scenario, mut config) = fixture([1, 1]);
    config.history_limit = 1;
    let mut world = CourseWorld::new_population(scenario, config).unwrap();
    for _ in 0..4 {
        world.step();
    }
    let population = world.population_snapshot().unwrap();
    assert_eq!(population.totals.births, 2);
    assert_eq!(population.history.events.len(), 1);
    assert_eq!(population.history.evicted_events, 2);
    assert_eq!(population.history.complete_after_tick, 3);
    assert_eq!(population.history.births_between(1, 4), None);
    assert_eq!(population.history.births_between(4, 4), Some(1));
    assert_eq!(population.history.births_between(4, 5), None);
    assert_eq!(population.history.births_between(0, 4), None);
    assert_eq!(population.individuals[2].origin.unwrap().birth_tick, 1);
}

#[test]
fn birth_and_death_accounting_holds_for_forty_ticks_of_turnover() {
    for traits in [[1, 1], [1, 2], [2, 2], [1, 3]] {
        for pulsed in [false, true] {
            let (mut scenario, config) = fixture(traits);
            scenario.daylight = Daylight::new(4, if pulsed { 2 } else { 4 }).unwrap();
            scenario.patches[0].growth_units_per_lit_tick = if pulsed { 12 } else { 6 };
            let mut world = CourseWorld::new_population(scenario, config).unwrap();
            for _ in 0..40 {
                let before = stores(&world.snapshot());
                world.step();
                let state = world.snapshot();
                let population = world.population_snapshot().unwrap();
                assert_eq!(
                    stores(&state)
                        + state.ledger.maintenance_units
                        + population.ledger.dissipated_units,
                    before + state.ledger.added_units
                );
                assert_eq!(
                    population.living as u64 + population.totals.starvations,
                    population.totals.initial_founders + population.totals.births
                );
                assert!(population.living <= population.config.max_living);
                assert_eq!(population.living, population.juveniles + population.adults);
            }
        }
    }
}

#[test]
fn full_reports_are_independent_of_spawn_order_and_repeated_reads() {
    let (mut scenario, config) = fixture([1, 2]);
    scenario.patches.push(PatchSeed {
        id: SimId(50),
        biomass_units: 0,
        capacity_units: 1,
        growth_units_per_lit_tick: 1,
    });
    let mut reversed = scenario.clone();
    reversed.grazers.reverse();
    reversed.patches.reverse();
    let mut reversed_config = config.clone();
    reversed_config.founders.reverse();
    let mut direct = CourseWorld::new_population(scenario, config).unwrap();
    let mut observed = CourseWorld::new_population(reversed, reversed_config).unwrap();
    assert_eq!(direct.population_snapshot(), observed.population_snapshot());
    for _ in 0..12 {
        direct.step();
        for _ in 0..5 {
            let _ = observed.snapshot();
            let _ = observed.population_snapshot();
        }
        observed.step();
        assert_eq!(direct.snapshot(), observed.snapshot());
        assert_eq!(direct.population_snapshot(), observed.population_snapshot());
    }
}

#[test]
fn a_parent_without_a_funded_partner_or_shared_site_cannot_be_debited() {
    for reserve in [3, 4] {
        for shared_site in [false, true] {
            let (mut scenario, config) = fixture([1, 1]);
            scenario.grazers[0].reserve_units = 8;
            scenario.grazers[1].reserve_units = reserve;
            for seed in &mut scenario.grazers {
                seed.meal_units_per_tick = 0;
            }
            if !shared_site {
                scenario.grazers[1].feeding_site = None;
            }
            scenario.patches[0].growth_units_per_lit_tick = 0;
            let mut world = CourseWorld::new_population(scenario, config).unwrap();
            world.step();
            let state = world.snapshot();
            let population = world.population_snapshot().unwrap();
            // The second parent has at most 3 after upkeep: no positive remainder
            // would remain after contribution2 + cost1, even at a valid site.
            assert_eq!(reserves(&state), vec![(1, 7), (2, reserve - 1)]);
            assert_eq!(population.next_child_id, Some(SimId(101)));
            assert_eq!(population.next_birth_ordinal, 0);
            assert_eq!(population.ledger, Default::default());
            assert!(population.history.events.is_empty());
            assert_eq!(population.individuals[0].next_birth_tick, 1);
        }
    }
}

#[test]
fn reset_preserves_mode_and_failed_mode_switch_is_atomic() {
    let (scenario, config) = fixture([1, 1]);
    let mut world = CourseWorld::new_population(scenario.clone(), config.clone()).unwrap();
    world.step();
    let before = world.snapshot();
    let population = world.population_snapshot();
    let mut bad = config.clone();
    bad.mutation_cycle = vec![2];
    assert_eq!(
        world.reset_with_population(scenario.clone(), bad),
        Err(PopulationError::InvalidMutationCycle)
    );
    assert_eq!(world.snapshot(), before);
    assert_eq!(world.population_snapshot(), population);
    world.reset();
    assert_eq!(world.snapshot().run, 2);
    assert_eq!(world.snapshot().tick, 0);
    assert_eq!(world.population_snapshot().unwrap().totals.births, 0);
    world.step();
    assert_eq!(
        world.population_snapshot().unwrap().individuals[2]
            .origin
            .unwrap()
            .run,
        2
    );
    world.reset_with(Scenario::limited_supply()).unwrap();
    assert_eq!(world.snapshot().run, 3);
    assert!(world.population_snapshot().is_none());
    world.reset();
    assert_eq!(world.snapshot().run, 4);
    assert!(world.population_snapshot().is_none());
    world.reset_with_population(scenario, config).unwrap();
    assert_eq!(world.snapshot().run, 5);
    assert!(world.population_snapshot().is_some());
}

#[test]
fn population_validation_rejects_missing_traits_bounds_and_invalid_cycles() {
    let (scenario, config) = fixture([1, 2]);
    let cases: Vec<(PopulationConfig, PopulationError)> = vec![
        (
            {
                let mut value = config.clone();
                value.founders.pop();
                value
            },
            PopulationError::MissingFounder(SimId(2)),
        ),
        (
            {
                let mut value = config.clone();
                value.founders.push(value.founders[0]);
                value
            },
            PopulationError::DuplicateFounder(SimId(1)),
        ),
        (
            {
                let mut value = config.clone();
                value.founders[0].id = SimId(100);
                value
            },
            PopulationError::UnexpectedFounder(SimId(100)),
        ),
        (
            {
                let mut value = config.clone();
                value.founders[0].upkeep = UpkeepTrait::new(3).unwrap();
                value
            },
            PopulationError::UpkeepMismatch(SimId(1)),
        ),
        (
            {
                let mut value = config.clone();
                value.maturation_ticks = 0;
                value
            },
            PopulationError::InvalidMaturation,
        ),
        (
            {
                let mut value = config.clone();
                value.cooldown_ticks = 0;
                value
            },
            PopulationError::InvalidCooldown,
        ),
        (
            {
                let mut value = config.clone();
                value.contribution_units_per_parent = 0;
                value
            },
            PopulationError::InvalidContribution,
        ),
        (
            {
                let mut value = config.clone();
                value.contribution_units_per_parent = u32::MAX;
                value
            },
            PopulationError::PaymentOverflow,
        ),
        (
            {
                let mut value = config.clone();
                value.child_capacity_units = 3;
                value
            },
            PopulationError::ChildCapacityTooSmall,
        ),
        (
            {
                let mut value = config.clone();
                value.max_living = 0;
                value
            },
            PopulationError::InvalidLivingLimit,
        ),
        (
            {
                let mut value = config.clone();
                value.max_living = 1;
                value
            },
            PopulationError::OverLivingLimit,
        ),
        (
            {
                let mut value = config.clone();
                value.mutation_cycle = vec![];
                value
            },
            PopulationError::InvalidMutationCycle,
        ),
        (
            {
                let mut value = config.clone();
                value.mutation_cycle = vec![2];
                value
            },
            PopulationError::InvalidMutationCycle,
        ),
        (
            {
                let mut value = config.clone();
                value.mutation_cycle = vec![-3];
                value
            },
            PopulationError::InvalidMutationCycle,
        ),
    ];
    let mut live = CourseWorld::new_population(scenario.clone(), config).unwrap();
    live.step();
    let before = live.snapshot();
    let population = live.population_snapshot();
    for (invalid, error) in cases {
        assert_eq!(
            CourseWorld::new_population(scenario.clone(), invalid.clone()).err(),
            Some(error)
        );
        assert_eq!(
            live.reset_with_population(scenario.clone(), invalid),
            Err(error)
        );
        assert_eq!(live.snapshot(), before);
        assert_eq!(live.population_snapshot(), population);
    }
    assert_eq!(UpkeepTrait::new(0), Err(PopulationError::InvalidTrait(0)));
    assert_eq!(UpkeepTrait::new(4), Err(PopulationError::InvalidTrait(4)));
}

#[test]
fn empty_population_remains_empty_and_exhausted_authored_ids_are_rejected() {
    let scenario = Scenario {
        daylight: Daylight::new(1, 1).unwrap(),
        grazers: vec![],
        patches: vec![],
        history_limit: 0,
    };
    let mut world =
        CourseWorld::new_population(scenario.clone(), PopulationConfig::new(vec![])).unwrap();
    world.step();
    let population = world.population_snapshot().unwrap();
    assert_eq!(population.living, 0);
    assert_eq!(population.history.births_between(1, 1), Some(0));
    let mut invalid = scenario;
    invalid.patches.push(PatchSeed {
        id: SimId(u32::MAX),
        biomass_units: 0,
        capacity_units: 0,
        growth_units_per_lit_tick: 0,
    });
    assert_eq!(
        CourseWorld::new_population(invalid, PopulationConfig::new(vec![])).err(),
        Some(PopulationError::NoChildIdentity)
    );
}
