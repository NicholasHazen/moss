use moss_course_ecosystem::{
    Activity, CourseWorld, EventKind, FounderTrait, GrazerPlacement, MobileError, MobileScenario,
    MobileSnapshot, RestPolicy, SimId, UpkeepTrait,
};

fn alter(
    spec: &MobileScenario,
    f: impl FnOnce(
        &mut moss_course_ecosystem::Scenario,
        &mut moss_course_ecosystem::PopulationConfig,
        &mut moss_course_ecosystem::SpatialConfig,
    ),
) -> MobileScenario {
    let mut scenario = spec.scenario().clone();
    let mut population = spec.population().clone();
    let mut space = spec.space().clone();
    f(&mut scenario, &mut population, &mut space);
    let mut result =
        MobileScenario::new(scenario, population, space).with_history_limit(spec.history_limit());
    if let Some(policy) = spec.rest() {
        result = result.with_rest(*policy);
    }
    result
}

fn stores(report: &MobileSnapshot) -> u64 {
    report
        .base
        .grazers
        .iter()
        .map(|g| u64::from(g.reserve_units))
        .sum::<u64>()
        + report
            .base
            .patches
            .iter()
            .map(|p| u64::from(p.biomass_units))
            .sum::<u64>()
}

#[test]
fn actual_journey_stops_twice_then_wakes_with_a_fresh_local_view() {
    let mut world = CourseWorld::new_mobile(MobileScenario::resting_journey()).unwrap();
    for (tick, x, reserve, fatigue, remaining) in [
        (1, 1, 18, 2, None),
        (2, 2, 16, 4, None),
        (3, 3, 14, 6, None),
        (4, 3, 13, 4, Some(1)),
        (5, 3, 12, 2, Some(0)),
        (6, 4, 10, 4, None),
        (7, 5, 10, 6, None),
        (8, 5, 9, 4, Some(1)),
        (9, 5, 8, 2, Some(0)),
        (10, 5, 9, 2, None),
    ] {
        world.step();
        let mobile = world.mobile_snapshot().unwrap();
        let rest = world.rest_snapshot().unwrap();
        assert_eq!(
            (
                rest.tick,
                mobile.grazers[0].cell.x,
                mobile.base.grazers[0].reserve_units,
                rest.grazers[0].fatigue_points
            ),
            (tick, x, reserve, fatigue)
        );
        assert_eq!(
            rest.grazers[0].activity,
            remaining.map_or(Activity::Foraging, |remaining_ticks| Activity::Resting {
                remaining_ticks
            })
        );
        if remaining.is_some() {
            assert_eq!(mobile.grazers[0].target, None);
            assert_eq!(mobile.base.grazers[0].feeding_site, None);
            assert_eq!(mobile.ledger.travel_cells, 0);
            assert_eq!(mobile.base.ledger.eaten_units, 0);
            assert_eq!(rest.ledger.rest_actions, 1);
            assert_eq!(rest.grazers[0].last_rest_tick, Some(tick));
            assert_eq!(
                mobile.grazers[0].observed_tick,
                Some(if tick < 6 { 3 } else { 7 })
            );
        } else {
            assert_eq!(mobile.grazers[0].observed_tick, Some(tick));
        }
    }
    let report = world.rest_snapshot().unwrap();
    assert_eq!(
        (
            report.totals.effort_points,
            report.totals.recovered_points,
            report.totals.rest_actions,
            report.totals.entered_rest,
            report.totals.woke
        ),
        (10, 8, 4, 2, 2)
    );
}

#[test]
fn fast_recovery_still_owes_the_second_committed_action() {
    let policy = RestPolicy {
        recovery_points_per_tick: 10,
        ..Default::default()
    };
    let mut world =
        CourseWorld::new_mobile(MobileScenario::resting_journey().with_rest(policy)).unwrap();
    for _ in 0..4 {
        world.step();
    }
    let fourth = world.rest_snapshot().unwrap();
    assert_eq!(fourth.grazers[0].fatigue_points, 0);
    assert_eq!(
        fourth.grazers[0].activity,
        Activity::Resting { remaining_ticks: 1 }
    );
    for _ in 0..20 {
        assert_eq!(world.rest_snapshot().unwrap(), fourth);
    }
    world.step();
    let fifth = world.rest_snapshot().unwrap();
    assert_eq!(
        fifth.grazers[0].activity,
        Activity::Resting { remaining_ticks: 0 }
    );
    assert_eq!(
        (fifth.ledger.rest_actions, fifth.ledger.recovered_points),
        (1, 0)
    );
    assert_eq!(world.mobile_snapshot().unwrap().grazers[0].cell.x, 3);
    world.step();
    assert_eq!(
        world.rest_snapshot().unwrap().grazers[0].activity,
        Activity::Foraging
    );
    assert_eq!(world.mobile_snapshot().unwrap().grazers[0].cell.x, 4);
}

#[test]
fn exit_threshold_still_requires_actions_after_minimum_is_spent() {
    let policy = RestPolicy {
        minimum_rest_ticks: 1,
        recovery_points_per_tick: 1,
        ..Default::default()
    };
    let mut world =
        CourseWorld::new_mobile(MobileScenario::resting_journey().with_rest(policy)).unwrap();
    for _ in 0..4 {
        world.step();
    }
    for fatigue in [5, 4, 3, 2] {
        let state = world.rest_snapshot().unwrap();
        assert_eq!(
            state.grazers[0].activity,
            Activity::Resting { remaining_ticks: 0 }
        );
        assert_eq!(state.grazers[0].fatigue_points, fatigue);
        world.step();
    }
    assert_eq!(
        world.rest_snapshot().unwrap().grazers[0].activity,
        Activity::Foraging
    );
}

#[test]
fn travel_accepts_only_whole_effort_that_fits_without_overflow() {
    let spec = alter(&MobileScenario::resting_journey(), |_, _, space| {
        space.grazers[0].motion.max_cells_per_tick = u32::MAX;
    })
    .with_rest(RestPolicy {
        effort_points_per_cell: 3,
        ..Default::default()
    });
    let mut world = CourseWorld::new_mobile(spec).unwrap();
    world.step();
    assert_eq!(world.mobile_snapshot().unwrap().grazers[0].cell.x, 3);
    let state = world.rest_snapshot().unwrap();
    assert_eq!(
        (state.grazers[0].fatigue_points, state.ledger.effort_points),
        (9, 9)
    );
    let extreme = RestPolicy {
        maximum_fatigue_points: u32::MAX,
        effort_points_per_cell: u32::MAX,
        enter_at_points: u32::MAX,
        exit_at_points: 0,
        recovery_points_per_tick: u32::MAX,
        ..Default::default()
    };
    let mut world =
        CourseWorld::new_mobile(MobileScenario::resting_journey().with_rest(extreme)).unwrap();
    world.step();
    assert_eq!(
        world.rest_snapshot().unwrap().grazers[0].fatigue_points,
        u32::MAX
    );
    world.step();
    assert_eq!(world.rest_snapshot().unwrap().grazers[0].fatigue_points, 0);
}

#[test]
fn resting_beside_food_can_starve_without_a_hunger_override() {
    let spec = alter(&MobileScenario::resting_journey(), |scenario, _, space| {
        scenario.grazers[0].reserve_units = 5;
        scenario.grazers[0].meal_units_per_tick = 1;
        space.patches[0].cell.x = 1;
    })
    .with_rest(RestPolicy {
        minimum_rest_ticks: 5,
        enter_at_points: 2,
        exit_at_points: 0,
        ..Default::default()
    });
    let mut world = CourseWorld::new_mobile(spec).unwrap();
    for _ in 0..5 {
        world.step();
    }
    let mobile = world.mobile_snapshot().unwrap();
    let rest = world.rest_snapshot().unwrap();
    assert!(mobile.base.grazers.is_empty());
    assert!(rest.grazers.is_empty());
    assert_eq!(mobile.population.totals.starvations, 1);
    assert_eq!(mobile.base.patches[0].biomass_units, 19);
    assert_eq!(
        (rest.totals.rest_actions, rest.totals.recovered_points),
        (4, 2)
    );
    assert!(
        mobile
            .base
            .history
            .events
            .iter()
            .any(|e| e.tick == 5 && matches!(e.kind, EventKind::Starved { .. }))
    );
}

#[test]
fn resting_parents_cannot_reproduce_but_newborns_start_uncommitted() {
    let spec = alter(
        &MobileScenario::resting_journey(),
        |scenario, population, space| {
            let mut second = scenario.grazers[0].clone();
            second.id = SimId(2);
            scenario.grazers.push(second);
            population.founders.push(FounderTrait {
                id: SimId(2),
                upkeep: UpkeepTrait::new(1).unwrap(),
            });
            population.cooldown_ticks = 1;
            space.grazers.push(GrazerPlacement {
                id: SimId(2),
                ..space.grazers[0]
            });
            space.patches[0].cell.x = 3;
        },
    );
    let mut world = CourseWorld::new_mobile(spec).unwrap();
    for _ in 0..3 {
        world.step();
    }
    let born = world.mobile_snapshot().unwrap();
    assert_eq!(born.population.totals.births, 1);
    let child = born
        .population
        .history
        .events
        .iter()
        .find_map(|e| match e.kind {
            moss_course_ecosystem::PopulationEventKind::Born(record) => Some(record.child),
            _ => None,
        })
        .unwrap();
    let rest = world.rest_snapshot().unwrap();
    let newborn = rest.grazers.iter().find(|r| r.id == child).unwrap();
    assert_eq!(
        (
            newborn.fatigue_points,
            newborn.activity,
            newborn.last_rest_tick,
            newborn.last_transition_tick
        ),
        (0, Activity::Foraging, None, None)
    );
    world.step();
    world.step();
    let asleep = world.mobile_snapshot().unwrap();
    assert_eq!(asleep.population.totals.births, 1);
    assert_eq!(world.rest_snapshot().unwrap().totals.rest_actions, 4);
}

#[test]
fn zero_and_bounded_rest_history_preserve_unknown_intervals_and_known_totals() {
    let mut world =
        CourseWorld::new_mobile(MobileScenario::resting_journey().with_rest(RestPolicy {
            history_limit: 0,
            ..Default::default()
        }))
        .unwrap();
    for _ in 0..5 {
        world.step();
    }
    let rest = world.rest_snapshot().unwrap();
    assert!(rest.history.events.is_empty());
    assert_eq!(rest.totals.rest_actions, 2);
    assert_eq!(rest.history.rest_actions_between(1, 5), None);
    let stationary = alter(&MobileScenario::resting_journey(), |_, _, space| {
        space.grazers[0].motion.max_cells_per_tick = 0
    })
    .with_rest(RestPolicy {
        history_limit: 0,
        ..Default::default()
    });
    world.reset_with_mobile(stationary).unwrap();
    world.step();
    assert_eq!(
        world
            .rest_snapshot()
            .unwrap()
            .history
            .rest_actions_between(1, 1),
        Some(0)
    );
}

#[test]
fn invalid_rest_reset_is_atomic_and_every_mode_switch_clears_old_rest_state() {
    let spec = MobileScenario::resting_journey();
    let mut world = CourseWorld::new_mobile(spec.clone()).unwrap();
    for _ in 0..4 {
        world.step();
    }
    let mobile = world.mobile_snapshot().unwrap();
    let rest = world.rest_snapshot().unwrap();
    for bad in [
        RestPolicy {
            exit_at_points: 6,
            ..Default::default()
        },
        RestPolicy {
            enter_at_points: 11,
            ..Default::default()
        },
        RestPolicy {
            effort_points_per_cell: 0,
            ..Default::default()
        },
        RestPolicy {
            effort_points_per_cell: 11,
            ..Default::default()
        },
        RestPolicy {
            minimum_rest_ticks: 0,
            ..Default::default()
        },
        RestPolicy {
            recovery_points_per_tick: 0,
            ..Default::default()
        },
    ] {
        assert_eq!(
            world.reset_with_mobile(spec.clone().with_rest(bad)),
            Err(MobileError::InvalidRestPolicy)
        );
        assert_eq!(world.mobile_snapshot().unwrap(), mobile);
        assert_eq!(world.rest_snapshot().unwrap(), rest);
    }
    world.reset();
    assert_eq!(world.rest_snapshot().unwrap().run, 2);
    assert_eq!(world.rest_snapshot().unwrap().totals.rest_actions, 0);
    world
        .reset_with_mobile(MobileScenario::short_journey())
        .unwrap();
    assert!(world.rest_snapshot().is_none());
    world
        .reset_with_population(spec.scenario().clone(), spec.population().clone())
        .unwrap();
    assert!(world.rest_snapshot().is_none());
    world.reset_with(spec.scenario().clone()).unwrap();
    assert!(world.rest_snapshot().is_none());
}

#[test]
fn reports_are_owned_and_complete_order_and_read_frequency_do_not_change_rest() {
    let spec = MobileScenario::meadow().with_rest(RestPolicy::default());
    let reversed = alter(&spec, |scenario, population, space| {
        scenario.grazers.reverse();
        scenario.patches.reverse();
        population.founders.reverse();
        space.grazers.reverse();
        space.patches.reverse();
    });
    let mut first = CourseWorld::new_mobile(spec).unwrap();
    let mut second = CourseWorld::new_mobile(reversed).unwrap();
    for _ in 0..120 {
        first.step();
        second.step();
        let mut copy = first.rest_snapshot().unwrap();
        copy.grazers.clear();
        copy.history.events.clear();
        for _ in 0..3 {
            assert_eq!(first.rest_snapshot(), second.rest_snapshot());
            assert_eq!(first.mobile_snapshot(), second.mobile_snapshot());
        }
    }
}

#[test]
fn rested_meadow_preserves_energy_and_census_every_tick_for_both_minimums() {
    for minimum_rest_ticks in [2, 3] {
        let mut world = CourseWorld::new_mobile(MobileScenario::meadow().with_rest(RestPolicy {
            minimum_rest_ticks,
            ..Default::default()
        }))
        .unwrap();
        let mut before = stores(&world.mobile_snapshot().unwrap());
        for _ in 0..120 {
            world.step();
            let mobile = world.mobile_snapshot().unwrap();
            let rest = world.rest_snapshot().unwrap();
            let after = stores(&mobile);
            assert_eq!(
                before + mobile.base.ledger.added_units,
                after
                    + mobile.base.ledger.maintenance_units
                    + mobile.ledger.travel_units
                    + mobile.population.ledger.dissipated_units
            );
            assert_eq!(
                mobile.base.grazers.len() as u64 + mobile.population.totals.starvations,
                4 + mobile.population.totals.births
            );
            assert!(
                rest.grazers
                    .iter()
                    .all(|g| g.fatigue_points <= rest.policy.maximum_fatigue_points)
            );
            before = after;
        }
        let mobile = world.mobile_snapshot().unwrap();
        let rest = world.rest_snapshot().unwrap();
        let observed = (
            mobile.base.grazers.len(),
            mobile.population.totals.births,
            mobile.population.totals.starvations,
            mobile.totals.travel_cells,
            rest.totals.rest_actions,
            rest.totals.effort_points,
            rest.totals.recovered_points,
        );
        assert_eq!(
            observed,
            if minimum_rest_ticks == 2 {
                (0, 7, 11, 36, 21, 72, 42)
            } else {
                (1, 10, 13, 71, 53, 142, 106)
            }
        );
    }
}

#[test]
fn only_changing_minimum_two_to_three_delays_the_same_journey() {
    let mut two = CourseWorld::new_mobile(MobileScenario::resting_journey()).unwrap();
    let mut three =
        CourseWorld::new_mobile(MobileScenario::resting_journey().with_rest(RestPolicy {
            minimum_rest_ticks: 3,
            ..Default::default()
        }))
        .unwrap();
    for _ in 0..6 {
        two.step();
        three.step();
    }
    let a = two.mobile_snapshot().unwrap();
    let b = three.mobile_snapshot().unwrap();
    assert_eq!(
        (a.grazers[0].cell.x, a.base.grazers[0].reserve_units),
        (4, 10)
    );
    assert_eq!(
        (b.grazers[0].cell.x, b.base.grazers[0].reserve_units),
        (3, 11)
    );
    assert_eq!(
        two.rest_snapshot().unwrap().grazers[0].activity,
        Activity::Foraging
    );
    assert_eq!(
        three.rest_snapshot().unwrap().grazers[0].activity,
        Activity::Resting { remaining_ticks: 0 }
    );
    two.step();
    three.step();
    assert_eq!(two.mobile_snapshot().unwrap().base.ledger.eaten_units, 2);
    assert_eq!(three.mobile_snapshot().unwrap().base.ledger.eaten_units, 0);
    three.step();
    assert_eq!(three.mobile_snapshot().unwrap().base.ledger.eaten_units, 2);
}

#[test]
fn partial_tick_eviction_does_not_turn_missing_rest_into_zero() {
    let mut world =
        CourseWorld::new_mobile(MobileScenario::resting_journey().with_rest(RestPolicy {
            history_limit: 2,
            ..Default::default()
        }))
        .unwrap();
    for _ in 0..5 {
        world.step();
    }
    let state = world.rest_snapshot().unwrap();
    assert_eq!(state.history.events.len(), 2);
    assert_eq!(state.history.complete_after_tick, 4); // Entry4 lost, even though Rested4 remains.
    assert_eq!(state.history.rest_actions_between(4, 5), None);
    assert_eq!(state.history.rest_actions_between(5, 5), Some(1));
    assert_eq!(state.totals.rest_actions, 2);
}
