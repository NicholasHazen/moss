use moss_course_ecosystem::{
    Activity, Cell, CourseWorld, EventKind, HuntConfig, HuntEventKind, HunterSeed, MobileError,
    MobileScenario, Motion, RestPolicy, SimId,
};

fn change(
    spec: &MobileScenario,
    f: impl FnOnce(
        &mut moss_course_ecosystem::Scenario,
        &mut moss_course_ecosystem::PopulationConfig,
        &mut moss_course_ecosystem::SpatialConfig,
    ),
) -> MobileScenario {
    let mut s = spec.scenario().clone();
    let mut p = spec.population().clone();
    let mut x = spec.space().clone();
    f(&mut s, &mut p, &mut x);
    let mut result = MobileScenario::new(s, p, x).with_history_limit(spec.history_limit());
    if let Some(rest) = spec.rest() {
        result = result.with_rest(*rest);
    }
    if let Some(hunters) = spec.hunters() {
        result = result.with_hunters(hunters.clone());
    }
    result
}
fn without_hunters(spec: &MobileScenario) -> MobileScenario {
    let base = MobileScenario::new(
        spec.scenario().clone(),
        spec.population().clone(),
        spec.space().clone(),
    )
    .with_history_limit(spec.history_limit());
    if let Some(rest) = spec.rest() {
        base.with_rest(*rest)
    } else {
        base
    }
}
fn stores(world: &CourseWorld) -> u64 {
    let base = world.snapshot();
    base.grazers
        .iter()
        .map(|g| u64::from(g.reserve_units))
        .sum::<u64>()
        + base
            .patches
            .iter()
            .map(|p| u64::from(p.biomass_units))
            .sum::<u64>()
        + world.hunt_snapshot().map_or(0, |h| {
            h.hunters.iter().map(|h| u64::from(h.reserve_units)).sum()
        })
}
fn pursuit() -> MobileScenario {
    let seed = HunterSeed {
        id: SimId(50),
        reserve_units: 10,
        capacity_units: 20,
        maintenance_units_per_tick: 1,
        attack_units: 1,
        attack_effort_points: 2,
        cell: Cell { x: 0, y: 0 },
        motion: Motion {
            sensing_radius: 3,
            max_cells_per_tick: 1,
            travel_units_per_cell: 1,
        },
    };
    MobileScenario::short_journey()
        .with_rest(RestPolicy::default())
        .with_hunters(HuntConfig::new(vec![seed]))
}

#[test]
fn one_capture_uses_current_reserve_and_prevents_second_credit_meal_and_birth() {
    let spec = MobileScenario::hunting_contention();
    let mut control = CourseWorld::new_mobile(without_hunters(&spec)).unwrap();
    control.step();
    assert_eq!(control.population_snapshot().unwrap().totals.births, 1);
    let mut world = CourseWorld::new_mobile(spec).unwrap();
    assert_eq!(stores(&world), 28);
    world.step();
    let h = world.hunt_snapshot().unwrap();
    let m = world.mobile_snapshot().unwrap();
    assert_eq!(
        h.hunters
            .iter()
            .map(|h| h.reserve_units)
            .collect::<Vec<_>>(),
        vec![6, 3]
    );
    assert_eq!(h.hunters[0].last_capture_tick, Some(1));
    assert_eq!(h.hunters[1].last_capture_tick, None);
    assert_eq!(
        (
            h.totals.captures,
            h.totals.transferred_units,
            h.totals.attack_units,
            h.totals.maintenance_units
        ),
        (1, 4, 1, 2)
    );
    assert_eq!(h.hunters[0].fatigue_points, Some(2));
    assert_eq!(
        m.base
            .grazers
            .iter()
            .map(|g| (g.id, g.reserve_units))
            .collect::<Vec<_>>(),
        vec![(SimId(2), 6)]
    );
    assert_eq!(m.base.patches[0].biomass_units, 8);
    assert_eq!(
        (m.population.totals.births, m.population.totals.starvations),
        (0, 0)
    );
    assert!(!m.base.history.events.iter().any(|e| matches!(
        e.kind,
        EventKind::Meal {
            grazer: SimId(1),
            ..
        } | EventKind::Starved { grazer: SimId(1) }
    )));
    assert_eq!(
        stores(&world)
            + m.base.ledger.maintenance_units
            + h.ledger.maintenance_units
            + h.ledger.attack_units,
        28
    );
    assert!(h.history.events.iter().any(|e| matches!(
        e.kind,
        HuntEventKind::Captured {
            hunter: SimId(100),
            prey: SimId(1),
            transferred_units: 4,
            ..
        }
    )));
}

#[test]
fn full_transfer_capacity_rejection_leaves_the_prey_for_a_later_hunter() {
    let mut spec = MobileScenario::hunting_contention();
    let mut config = spec.hunters().unwrap().clone();
    config.hunters[0].capacity_units = 5;
    spec = spec.with_hunters(config);
    let mut world = CourseWorld::new_mobile(spec).unwrap();
    world.step();
    let h = world.hunt_snapshot().unwrap();
    assert_eq!(
        h.hunters
            .iter()
            .map(|h| h.reserve_units)
            .collect::<Vec<_>>(),
        vec![3, 6]
    );
    assert_eq!(h.hunters[0].fatigue_points, Some(0));
    assert_eq!(h.hunters[0].last_capture_tick, None);
    assert_eq!(h.totals.captures, 1);
    assert!(h.history.events.iter().any(|e| matches!(
        e.kind,
        HuntEventKind::Captured {
            hunter: SimId(101),
            ..
        }
    )));
}

#[test]
fn actual_prey_travel_invalidates_contact_without_privileged_tracking() {
    let mut world = CourseWorld::new_mobile(pursuit()).unwrap();
    for (tick, gx, hx, captures) in [(1, Some(1), 0, 0), (2, Some(2), 1, 0), (3, None, 2, 1)] {
        world.step();
        let h = world.hunt_snapshot().unwrap();
        let m = world.mobile_snapshot().unwrap();
        assert_eq!(m.grazers.first().map(|g| g.cell.x), gx);
        assert_eq!(
            (h.tick, h.hunters[0].cell.x, h.totals.captures),
            (tick, hx, captures)
        );
        assert_eq!(
            h.hunters[0].target.unwrap().observed_cell.x,
            (tick - 1) as u32
        );
    }
    let h = world.hunt_snapshot().unwrap();
    assert_eq!(
        (
            h.hunters[0].reserve_units,
            h.totals.transferred_units,
            h.totals.travel_cells
        ),
        (6, 2, 2)
    );
    assert_eq!(world.snapshot().patches[0].biomass_units, 1);
}

#[test]
fn hunter_cannot_borrow_attack_cost_from_the_expected_transfer() {
    let mut spec = MobileScenario::hunting_contention();
    let mut config = spec.hunters().unwrap().clone();
    config.hunters.truncate(1);
    config.hunters[0].reserve_units = 1;
    spec = spec.with_hunters(config);
    let mut world = CourseWorld::new_mobile(spec).unwrap();
    world.step();
    let h = world.hunt_snapshot().unwrap();
    assert_eq!(
        (
            h.totals.captures,
            h.totals.hunter_starvations,
            h.totals.attack_units
        ),
        (0, 1, 0)
    );
    assert!(h.hunters.is_empty());
    assert_eq!(world.population_snapshot().unwrap().totals.births, 1);
}

#[test]
fn zero_reserve_prey_has_no_modeled_transfer_and_can_eat_later() {
    let spec = change(&MobileScenario::hunting_contention(), |scenario, _, _| {
        scenario.grazers.truncate(1);
        scenario.grazers[0].reserve_units = 1;
    });
    // Keep the matching founder/placement sets exact.
    let spec = change(&spec, |_, population, space| {
        population.founders.truncate(1);
        space.grazers.truncate(1);
    });
    let mut world = CourseWorld::new_mobile(spec).unwrap();
    world.step();
    let h = world.hunt_snapshot().unwrap();
    assert_eq!(h.totals.captures, 0);
    assert!(h.hunters.iter().all(|h| h.visible_prey.is_empty()));
    assert_eq!(world.snapshot().grazers[0].reserve_units, 2);
}

#[test]
fn global_inspector_does_not_supply_a_hunter_target() {
    let mut spec = pursuit();
    let mut config = spec.hunters().unwrap().clone();
    config.hunters[0].cell = Cell { x: 3, y: 1 };
    config.hunters[0].motion.sensing_radius = 0;
    spec = spec.with_hunters(config);
    let mut world = CourseWorld::new_mobile(spec).unwrap();
    world.step();
    let h = world.hunt_snapshot().unwrap();
    assert!(!world.snapshot().grazers.is_empty());
    assert_eq!(h.hunters[0].target, None);
    assert!(h.hunters[0].visible_prey.is_empty());
    assert_eq!(h.ledger.travel_cells, 0);
}

#[test]
fn captured_prey_frees_a_grazer_slot_without_counting_as_starvation() {
    let spec = change(
        &MobileScenario::hunting_contention(),
        |scenario, population, space| {
            let mut third = scenario.grazers[0].clone();
            third.id = SimId(3);
            scenario.grazers.push(third);
            population
                .founders
                .push(moss_course_ecosystem::FounderTrait {
                    id: SimId(3),
                    upkeep: moss_course_ecosystem::UpkeepTrait::new(1).unwrap(),
                });
            population.max_living = 3;
            space.grazers.push(moss_course_ecosystem::GrazerPlacement {
                id: SimId(3),
                ..space.grazers[0]
            });
        },
    );
    let mut world = CourseWorld::new_mobile(spec).unwrap();
    world.step();
    let p = world.population_snapshot().unwrap();
    let h = world.hunt_snapshot().unwrap();
    assert_eq!(
        (
            p.living,
            p.totals.births,
            p.totals.starvations,
            h.totals.captures
        ),
        (3, 1, 0, 1)
    );
    assert_eq!(p.next_child_id, Some(SimId(1002)));
}

#[test]
fn child_allocator_includes_every_authored_hunter_identity() {
    let mut spec = MobileScenario::hunting_contention();
    let mut config = spec.hunters().unwrap().clone();
    config.hunters = vec![HunterSeed {
        id: SimId(4000),
        cell: Cell { x: 1, y: 0 },
        motion: Motion {
            sensing_radius: 0,
            max_cells_per_tick: 0,
            travel_units_per_cell: 1,
        },
        ..config.hunters[0].clone()
    }];
    spec = spec.with_hunters(config);
    let mut world = CourseWorld::new_mobile(spec).unwrap();
    assert_eq!(
        world.population_snapshot().unwrap().next_child_id,
        Some(SimId(4001))
    );
    world.step();
    assert!(world.snapshot().grazers.iter().any(|g| g.id == SimId(4001)));
    assert_eq!(world.hunt_snapshot().unwrap().living_hunters, 1);
}

#[test]
fn invalid_hunter_config_is_atomic_and_resets_keep_the_selected_mode() {
    let spec = MobileScenario::hunting_contention();
    let mut world = CourseWorld::new_mobile(spec.clone()).unwrap();
    world.step();
    let before = (
        world.mobile_snapshot(),
        world.rest_snapshot(),
        world.hunt_snapshot(),
    );
    for fault in 0..6 {
        let mut config = spec.hunters().unwrap().clone();
        match fault {
            0 => config.hunters[0].id = SimId(1),
            1 => config.hunters[0].id = SimId(1000),
            2 => config.hunters[0].reserve_units = 9,
            3 => config.hunters[0].attack_units = 0,
            4 => config.hunters[0].attack_effort_points = 11,
            _ => config.hunters[0].id = SimId(u32::MAX),
        };
        assert!(
            world
                .reset_with_mobile(spec.clone().with_hunters(config))
                .is_err()
        );
        assert_eq!(
            (
                world.mobile_snapshot(),
                world.rest_snapshot(),
                world.hunt_snapshot()
            ),
            before
        );
    }
    world.reset();
    assert_eq!(world.hunt_snapshot().unwrap().run, 2);
    assert_eq!(world.hunt_snapshot().unwrap().totals.captures, 0);
    world
        .reset_with_mobile(MobileScenario::resting_journey())
        .unwrap();
    assert!(world.hunt_snapshot().is_none());
    assert!(world.rest_snapshot().is_some());
    world.reset();
    assert!(world.hunt_snapshot().is_none());
    world
        .reset_with_population(spec.scenario().clone(), spec.population().clone())
        .unwrap();
    assert!(world.hunt_snapshot().is_none());
    world.reset_with(spec.scenario().clone()).unwrap();
    assert!(world.hunt_snapshot().is_none());
    let mut duplicate = spec.hunters().unwrap().clone();
    duplicate.hunters[1].id = duplicate.hunters[0].id;
    assert_eq!(
        world.reset_with_mobile(spec.with_hunters(duplicate)),
        Err(MobileError::DuplicateHunterId(SimId(100)))
    );
}

#[test]
fn evicted_capture_is_unknown_but_lifetime_cause_count_remains_known() {
    let spec = MobileScenario::hunting_contention();
    let mut config = spec.hunters().unwrap().clone();
    config.history_limit = 0;
    let mut world = CourseWorld::new_mobile(spec.with_hunters(config)).unwrap();
    world.step();
    let h = world.hunt_snapshot().unwrap();
    assert_eq!(h.totals.captures, 1);
    assert!(h.history.events.is_empty());
    assert_eq!(h.history.captures_between(1, 1), None);
    let mut empty = CourseWorld::new_mobile(
        MobileScenario::resting_journey().with_hunters(HuntConfig::new(Vec::new())),
    )
    .unwrap();
    empty.step();
    assert_eq!(
        empty
            .hunt_snapshot()
            .unwrap()
            .history
            .captures_between(1, 1),
        Some(0)
    );
}

#[test]
fn hunter_rest_is_committed_and_does_not_pollute_grazer_rest_counters() {
    let mut world = CourseWorld::new_mobile(pursuit()).unwrap();
    for _ in 0..4 {
        world.step();
    }
    let h = world.hunt_snapshot().unwrap();
    assert_eq!(
        h.hunters[0].activity,
        Activity::Resting { remaining_ticks: 1 }
    );
    assert_eq!(h.hunters[0].target, None);
    assert_eq!(
        (h.totals.rest_actions, h.hunters[0].fatigue_points),
        (1, Some(4))
    );
    assert_eq!(world.rest_snapshot().unwrap().totals.rest_actions, 0);
    world.step();
    let h = world.hunt_snapshot().unwrap();
    assert_eq!(
        h.hunters[0].activity,
        Activity::Resting { remaining_ticks: 0 }
    );
    assert_eq!(h.hunters[0].reserve_units, 4);
    world.step();
    assert_eq!(
        world.hunt_snapshot().unwrap().hunters[0].activity,
        Activity::Foraging
    );
}

#[test]
fn complete_reports_are_canonical_owned_and_read_frequency_independent() {
    let spec = MobileScenario::meadow()
        .with_rest(RestPolicy::default())
        .with_hunters(HuntConfig::meadow());
    let mut reversed = change(&spec, |s, p, x| {
        s.grazers.reverse();
        s.patches.reverse();
        p.founders.reverse();
        x.grazers.reverse();
        x.patches.reverse();
    });
    let mut h = reversed.hunters().unwrap().clone();
    h.hunters.reverse();
    reversed = reversed.with_hunters(h);
    let mut a = CourseWorld::new_mobile(spec).unwrap();
    let mut b = CourseWorld::new_mobile(reversed).unwrap();
    for _ in 0..120 {
        a.step();
        b.step();
        let mut copy = a.hunt_snapshot().unwrap();
        copy.hunters.clear();
        copy.config.hunters.clear();
        copy.history.events.clear();
        for _ in 0..3 {
            assert_eq!(
                (a.mobile_snapshot(), a.rest_snapshot(), a.hunt_snapshot()),
                (b.mobile_snapshot(), b.rest_snapshot(), b.hunt_snapshot())
            );
        }
    }
}

#[test]
fn every_tick_closes_full_stores_and_both_censuses_in_the_matched_matrix() {
    for minimum_rest_ticks in [2, 3] {
        for hunters in [false, true] {
            let mut spec = MobileScenario::meadow().with_rest(RestPolicy {
                minimum_rest_ticks,
                ..Default::default()
            });
            if hunters {
                spec = spec.with_hunters(HuntConfig::meadow());
            }
            let mut world = CourseWorld::new_mobile(spec).unwrap();
            let mut before = stores(&world);
            for _ in 0..120 {
                world.step();
                let m = world.mobile_snapshot().unwrap();
                let h = world.hunt_snapshot();
                let c = h.as_ref().map_or(Default::default(), |h| h.ledger);
                let totals = h.as_ref().map_or(Default::default(), |h| h.totals);
                let after = stores(&world);
                assert_eq!(
                    before + m.base.ledger.added_units,
                    after
                        + m.base.ledger.maintenance_units
                        + m.ledger.travel_units
                        + m.population.ledger.dissipated_units
                        + c.maintenance_units
                        + c.travel_units
                        + c.attack_units
                );
                assert_eq!(
                    m.base.grazers.len() as u64 + m.population.totals.starvations + totals.captures,
                    4 + m.population.totals.births
                );
                assert_eq!(
                    h.as_ref().map_or(0, |h| h.living_hunters) as u64 + totals.hunter_starvations,
                    if hunters { 2 } else { 0 }
                );
                before = after;
            }
            if hunters {
                let h = world.hunt_snapshot().unwrap();
                let m = world.mobile_snapshot().unwrap();
                assert_eq!(
                    (
                        m.base.grazers.len(),
                        h.living_hunters,
                        m.population.totals.births,
                        m.population.totals.starvations,
                        h.totals.captures,
                        h.totals.hunter_starvations
                    ),
                    if minimum_rest_ticks == 2 {
                        (0, 0, 3, 4, 3, 2)
                    } else {
                        (0, 0, 3, 3, 4, 2)
                    }
                );
                assert_eq!(
                    (
                        m.totals.travel_cells,
                        h.totals.travel_cells,
                        h.totals.transferred_units,
                        h.totals.maintenance_units
                    ),
                    if minimum_rest_ticks == 2 {
                        (15, 13, 46, 62)
                    } else {
                        (14, 11, 55, 72)
                    }
                );
            }
        }
    }
}

#[test]
fn the_pilot_couples_descendant_actions_maturation_rest_and_capture_in_one_world() {
    let mut world = CourseWorld::new_mobile(
        MobileScenario::meadow()
            .with_rest(RestPolicy::default())
            .with_hunters(HuntConfig::meadow()),
    )
    .unwrap();
    for _ in 0..12 {
        world.step();
    }
    let m = world.mobile_snapshot().unwrap();
    let r = world.rest_snapshot().unwrap();
    let h = world.hunt_snapshot().unwrap();
    let children: Vec<_> = m
        .population
        .history
        .events
        .iter()
        .filter_map(|e| match e.kind {
            moss_course_ecosystem::PopulationEventKind::Born(record) => {
                Some((record.child, record.first_eligible_tick))
            }
            _ => None,
        })
        .collect();
    assert!(!children.is_empty());
    assert!(m.population.history.events.iter().any(|e| matches!(
        e.kind,
        moss_course_ecosystem::PopulationEventKind::Matured { .. }
    )));
    assert!(m.base.history.events.iter().any(|e| {
        match e.kind {
            EventKind::Maintenance { grazer, units } => {
                units > 0
                    && children
                        .iter()
                        .any(|&(id, first)| id == grazer && e.tick >= first)
            }
            _ => false,
        }
    }));
    assert!(r.totals.rest_actions > 0 && h.totals.rest_actions > 0 && h.totals.captures > 0);
    assert_eq!(
        (
            m.base.history.complete_after_tick,
            m.population.history.complete_after_tick,
            m.history.complete_after_tick,
            r.history.complete_after_tick,
            h.history.complete_after_tick
        ),
        (0, 0, 0, 0, 0)
    );
}

#[test]
fn optional_fatigue_can_be_disabled_without_disabling_hunters_or_energy_costs() {
    let source = MobileScenario::hunting_contention();
    let spec = MobileScenario::new(
        source.scenario().clone(),
        source.population().clone(),
        source.space().clone(),
    )
    .with_hunters(source.hunters().unwrap().clone());
    let mut world = CourseWorld::new_mobile(spec).unwrap();
    world.step();
    let h = world.hunt_snapshot().unwrap();
    assert!(world.rest_snapshot().is_none());
    assert_eq!(
        (
            h.totals.captures,
            h.totals.attack_units,
            h.totals.effort_points
        ),
        (1, 1, 0)
    );
    assert!(
        h.hunters
            .iter()
            .all(|hunter| hunter.fatigue_points.is_none() && hunter.activity == Activity::Foraging)
    );
}
