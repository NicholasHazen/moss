use moss_course_ecosystem::{
    Cell, CourseWorld, Daylight, EventKind, FounderTrait, GrazerPlacement, MobileError,
    MobileEventKind, MobileScenario, MobileSnapshot, PatchPlacement, PatchSeed, PopulationConfig,
    Scenario, SimId, UpkeepTrait,
};

fn parts(
    spec: &MobileScenario,
) -> (
    Scenario,
    PopulationConfig,
    moss_course_ecosystem::SpatialConfig,
) {
    (
        spec.scenario().clone(),
        spec.population().clone(),
        spec.space().clone(),
    )
}

fn stores(report: &MobileSnapshot) -> u64 {
    report
        .base
        .grazers
        .iter()
        .map(|grazer| u64::from(grazer.reserve_units))
        .sum::<u64>()
        + report
            .base
            .patches
            .iter()
            .map(|patch| u64::from(patch.biomass_units))
            .sum::<u64>()
}

fn paired() -> MobileScenario {
    let (mut scenario, mut population, mut space) = parts(&MobileScenario::short_journey());
    scenario.grazers.push({
        let mut seed = scenario.grazers[0].clone();
        seed.id = SimId(2);
        seed
    });
    population.founders.push(FounderTrait {
        id: SimId(2),
        upkeep: UpkeepTrait::new(1).unwrap(),
    });
    space.grazers.push(GrazerPlacement {
        id: SimId(2),
        ..space.grazers[0]
    });
    for placement in &mut space.grazers {
        placement.cell = Cell { x: 1, y: 1 };
    }
    space.patches[0].cell = Cell { x: 1, y: 1 };
    MobileScenario::new(scenario, population, space)
}

#[test]
fn literal_journey_spends_travel_then_eats_only_after_arrival() {
    let mut world = CourseWorld::new_mobile(MobileScenario::short_journey()).unwrap();
    let initial = world.mobile_snapshot().unwrap();
    assert_eq!(initial.tick, 0);
    assert_eq!(initial.grazers[0].observed_tick, None);
    assert_eq!(initial.grazers[0].observed_cell, None);
    for (tick, x, reserve, biomass, travelled) in
        [(1, 1, 3, 3, 1), (2, 2, 3, 1, 1), (3, 2, 3, 0, 0)]
    {
        world.step();
        let state = world.mobile_snapshot().unwrap();
        assert_eq!(
            state.grazers[0].observed_cell,
            Some(Cell {
                x: if tick == 1 {
                    0
                } else if tick == 2 {
                    1
                } else {
                    2
                },
                y: 0
            })
        );
        assert_eq!(
            (
                state.tick,
                state.grazers[0].cell.x,
                state.base.grazers[0].reserve_units,
                state.base.patches[0].biomass_units,
                state.ledger.travel_cells
            ),
            (tick, x, reserve, biomass, travelled)
        );
        assert_eq!(
            state.base.ledger.eaten_units,
            if tick == 1 {
                0
            } else if tick == 2 {
                2
            } else {
                1
            }
        );
        assert_eq!(
            state.base.grazers[0].feeding_site,
            if tick == 1 { None } else { Some(SimId(100)) }
        );
    }
    assert_eq!(
        world
            .mobile_snapshot()
            .unwrap()
            .history
            .travelled_cells_between(1, 3),
        Some(2)
    );
}

#[test]
fn travel_is_cardinal_x_first_affordable_and_can_be_rescued_on_arrival() {
    for reversed in [false, true] {
        let (mut scenario, population, mut space) = parts(&MobileScenario::short_journey());
        scenario.grazers[0].reserve_units = 10;
        scenario.grazers[0].capacity_units = 10;
        space.bounds.height_cells = 3;
        space.grazers[0].cell = if reversed {
            Cell { x: 2, y: 2 }
        } else {
            Cell { x: 0, y: 0 }
        };
        space.patches[0].cell = if reversed {
            Cell { x: 0, y: 0 }
        } else {
            Cell { x: 2, y: 2 }
        };
        space.grazers[0].motion.sensing_radius = 4;
        space.grazers[0].motion.max_cells_per_tick = 3;
        space.grazers[0].motion.travel_units_per_cell = 2;
        let mut world =
            CourseWorld::new_mobile(MobileScenario::new(scenario, population, space)).unwrap();
        world.step();
        let first = world.mobile_snapshot().unwrap();
        assert_eq!(
            first.grazers[0].cell,
            Cell {
                x: if reversed { 0 } else { 2 },
                y: 1
            }
        );
        assert_eq!(
            (
                first.base.grazers[0].reserve_units,
                first.ledger.travel_cells,
                first.ledger.travel_units
            ),
            (3, 3, 6)
        );
        world.step();
        let second = world.mobile_snapshot().unwrap();
        assert_eq!(second.base.grazers[0].reserve_units, 2);
        assert_eq!(second.ledger.travel_cells, 1);
        assert_eq!(second.base.ledger.starvations, 0);
    }
}

#[test]
fn partial_affordability_and_zero_speed_do_not_overspend_or_teleport() {
    for speed in [0, 10] {
        let (mut scenario, population, mut space) = parts(&MobileScenario::short_journey());
        scenario.grazers[0].reserve_units = 6;
        space.bounds.width_cells = 6;
        space.patches[0].cell.x = 5;
        space.grazers[0].motion.sensing_radius = 5;
        space.grazers[0].motion.max_cells_per_tick = speed;
        space.grazers[0].motion.travel_units_per_cell = 2;
        let mut world =
            CourseWorld::new_mobile(MobileScenario::new(scenario, population, space)).unwrap();
        world.step();
        let state = world.mobile_snapshot().unwrap();
        let cells = if speed == 0 { 0 } else { 2 };
        assert_eq!(state.grazers[0].cell.x, cells);
        assert_eq!(state.base.grazers[0].reserve_units, 5 - cells * 2);
        assert_eq!(state.base.ledger.eaten_units, 0);
        assert_eq!(state.base.patches[0].biomass_units, 3);
    }
}

#[test]
fn inspector_visibility_does_not_grant_perception_or_remote_contact() {
    for radius in [0, 1, 2] {
        let (scenario, population, mut space) = parts(&MobileScenario::short_journey());
        space.grazers[0].motion.sensing_radius = radius;
        space.grazers[0].motion.max_cells_per_tick = 0;
        let mut world =
            CourseWorld::new_mobile(MobileScenario::new(scenario, population, space)).unwrap();
        world.step();
        let state = world.mobile_snapshot().unwrap();
        assert_eq!(state.base.patches.len(), 1);
        assert_eq!(
            state.grazers[0].visible_patches.len(),
            if radius == 2 { 1 } else { 0 }
        );
        assert_eq!(state.grazers[0].target.is_some(), radius == 2);
        assert_eq!(state.base.grazers[0].reserve_units, 4);
        assert_eq!(state.base.ledger.eaten_units, 0);
    }
}

#[test]
fn equal_distance_ties_use_identity_and_empty_patches_are_still_observed() {
    let (mut scenario, population, mut space) = parts(&MobileScenario::short_journey());
    space.bounds.height_cells = 3;
    space.patches[0].cell = Cell { x: 1, y: 0 };
    scenario.patches.push(PatchSeed {
        id: SimId(99),
        biomass_units: 2,
        capacity_units: 2,
        growth_units_per_lit_tick: 0,
    });
    scenario.patches.push(PatchSeed {
        id: SimId(98),
        biomass_units: 0,
        capacity_units: 2,
        growth_units_per_lit_tick: 0,
    });
    space.patches.push(PatchPlacement {
        id: SimId(99),
        cell: Cell { x: 0, y: 1 },
    });
    space.patches.push(PatchPlacement {
        id: SimId(98),
        cell: Cell { x: 0, y: 0 },
    });
    let mut world =
        CourseWorld::new_mobile(MobileScenario::new(scenario, population, space)).unwrap();
    world.step();
    let state = world.mobile_snapshot().unwrap();
    assert_eq!(state.grazers[0].target.unwrap().patch, SimId(99));
    assert_eq!(state.grazers[0].cell, Cell { x: 0, y: 1 });
    assert_eq!(state.grazers[0].visible_patches[0].biomass_units, 0);
}

#[test]
fn an_actual_competing_meal_invalidates_the_later_owned_observation() {
    let (mut scenario, mut population, space) = parts(&paired());
    scenario.patches[0].biomass_units = 1;
    population.max_living = 2; // Explicitly isolate feeding; funded births are cap-denied.
    let mut world =
        CourseWorld::new_mobile(MobileScenario::new(scenario, population, space)).unwrap();
    world.step();
    let state = world.mobile_snapshot().unwrap();
    assert_eq!(
        state
            .base
            .grazers
            .iter()
            .map(|grazer| grazer.reserve_units)
            .collect::<Vec<_>>(),
        [5, 4]
    );
    assert_eq!(state.base.patches[0].biomass_units, 0);
    for grazer in &state.grazers {
        assert_eq!(grazer.visible_patches[0].biomass_units, 1);
    }
    let meals: Vec<_> = state
        .base
        .history
        .events
        .iter()
        .filter_map(|event| {
            if let EventKind::Meal { grazer, units, .. } = event.kind {
                Some((grazer, units))
            } else {
                None
            }
        })
        .collect();
    assert_eq!(meals, [(SimId(1), 1)]);
    assert_eq!(state.population.totals.births, 0);
}

#[test]
fn valid_target_is_retained_when_supply_renews_at_a_nearer_patch() {
    let (mut scenario, population, mut space) = parts(&MobileScenario::short_journey());
    scenario.daylight = Daylight::new(4, 2).unwrap();
    scenario.grazers[0].reserve_units = 20;
    scenario.grazers[0].capacity_units = 20;
    scenario.grazers[0].meal_units_per_tick = 1;
    scenario.patches[0].biomass_units = 20;
    scenario.patches[0].capacity_units = 20;
    scenario.patches.push(PatchSeed {
        id: SimId(101),
        biomass_units: 0,
        capacity_units: 5,
        growth_units_per_lit_tick: 1,
    });
    space.bounds.width_cells = 7;
    space.grazers[0].motion.sensing_radius = 6;
    space.patches[0].cell.x = 6;
    space.patches.push(PatchPlacement {
        id: SimId(101),
        cell: Cell { x: 0, y: 0 },
    });
    let mut world =
        CourseWorld::new_mobile(MobileScenario::new(scenario, population, space)).unwrap();
    for _ in 0..5 {
        world.step();
    }
    let state = world.mobile_snapshot().unwrap();
    assert_eq!(state.grazers[0].cell.x, 3);
    assert_eq!(state.grazers[0].target.unwrap().patch, SimId(100));
    assert_eq!(state.grazers[0].target.unwrap().observed_tick, 5);
    assert_eq!(state.grazers[0].visible_patches[1].biomass_units, 1);
    assert_eq!(state.totals.target_changes, 2);
}

#[test]
fn spatial_birth_places_a_newborn_without_target_or_an_early_turn() {
    let (mut scenario, population, mut space) = parts(&paired());
    scenario.daylight = Daylight::new(1, 1).unwrap();
    scenario.patches[0].biomass_units = 0;
    scenario.patches[0].capacity_units = 20;
    scenario.patches[0].growth_units_per_lit_tick = 6;
    space.newborn_motion.travel_units_per_cell = 2;
    let mut world =
        CourseWorld::new_mobile(MobileScenario::new(scenario, population, space.clone())).unwrap();
    world.step();
    let first = world.mobile_snapshot().unwrap();
    assert_eq!(first.population.totals.births, 1);
    let child = &first.grazers[2];
    assert_eq!(
        (child.id, child.cell, child.motion),
        (SimId(101), Cell { x: 1, y: 1 }, space.newborn_motion)
    );
    assert_eq!(
        (child.target, child.observed_tick, child.last_travel_tick),
        (None, None, None)
    );
    assert!(child.visible_patches.is_empty());
    assert_eq!(child.observed_cell, None);
    assert_eq!(first.base.grazers[2].reserve_units, 4);
    assert_eq!(first.base.grazers[2].feeding_site, None);
    assert!(first.history.events.iter().any(|event| event.kind
        == MobileEventKind::BornAt {
            child: SimId(101),
            cell: Cell { x: 1, y: 1 }
        }));
    world.step();
    let second = world.mobile_snapshot().unwrap();
    assert_eq!(second.base.grazers[2].reserve_units, 5);
    assert_eq!(second.grazers[2].observed_tick, Some(2));
    assert_eq!(second.grazers[2].last_travel_tick, Some(2));
}

#[test]
fn parents_targeting_the_same_patch_cannot_reproduce_from_different_cells() {
    let (mut scenario, population, mut space) = parts(&paired());
    for seed in &mut scenario.grazers {
        seed.reserve_units = 8;
        seed.meal_units_per_tick = 0;
    }
    space.grazers[1].cell.x = 0;
    for placement in &mut space.grazers {
        placement.motion.max_cells_per_tick = 0;
    }
    let mut world =
        CourseWorld::new_mobile(MobileScenario::new(scenario, population, space)).unwrap();
    world.step();
    let state = world.mobile_snapshot().unwrap();
    assert_eq!(
        state.grazers[0].target.unwrap().patch,
        state.grazers[1].target.unwrap().patch
    );
    assert_eq!(state.population.totals.births, 0);
    assert_eq!(
        state
            .base
            .grazers
            .iter()
            .map(|grazer| grazer.reserve_units)
            .collect::<Vec<_>>(),
        [7, 7]
    );
}

#[test]
fn complete_reports_are_canonical_owned_and_read_frequency_independent() {
    let direct_spec = MobileScenario::meadow();
    let (mut scenario, mut population, mut space) = parts(&direct_spec);
    scenario.grazers.reverse();
    scenario.patches.reverse();
    population.founders.reverse();
    space.grazers.reverse();
    space.patches.reverse();
    let mut direct = CourseWorld::new_mobile(direct_spec).unwrap();
    let mut observed =
        CourseWorld::new_mobile(MobileScenario::new(scenario, population, space)).unwrap();
    assert_eq!(direct.mobile_snapshot(), observed.mobile_snapshot());
    for _ in 0..40 {
        direct.step();
        for _ in 0..4 {
            let mut copy = observed.mobile_snapshot().unwrap();
            copy.grazers.clear();
            copy.base.grazers.clear();
            copy.population.individuals.clear();
        }
        observed.step();
        assert_eq!(direct.mobile_snapshot(), observed.mobile_snapshot());
    }
}

#[test]
fn travel_and_birth_accounting_hold_for_every_tick_of_the_longer_scene() {
    let mut world = CourseWorld::new_mobile(MobileScenario::meadow()).unwrap();
    for _ in 0..120 {
        let before = stores(&world.mobile_snapshot().unwrap());
        world.step();
        let state = world.mobile_snapshot().unwrap();
        assert_eq!(
            stores(&state)
                + state.base.ledger.maintenance_units
                + state.ledger.travel_units
                + state.population.ledger.dissipated_units,
            before + state.base.ledger.added_units
        );
        assert_eq!(
            state.population.living as u64 + state.population.totals.starvations,
            state.population.totals.initial_founders + state.population.totals.births
        );
        assert!(state.population.living <= state.initial.population().max_living);
        assert_eq!(state.grazers.len(), state.base.grazers.len());
        assert!(
            state
                .grazers
                .iter()
                .all(|grazer| state.initial.space().bounds.contains(grazer.cell))
        );
    }
}

#[test]
fn bounded_history_separates_lifetime_distance_from_known_empty_intervals() {
    for limit in [0, 1] {
        let mut world =
            CourseWorld::new_mobile(MobileScenario::short_journey().with_history_limit(limit))
                .unwrap();
        for _ in 0..3 {
            world.step();
        }
        let state = world.mobile_snapshot().unwrap();
        assert_eq!(state.totals.travel_cells, 2);
        assert!(state.history.events.len() <= limit);
        assert_eq!(state.history.travelled_cells_between(1, 3), None);
        assert_eq!(state.history.travelled_cells_between(3, 3), Some(0));
        assert_eq!(state.history.travelled_cells_between(3, 4), None);
        assert_eq!(state.history.travelled_cells_between(0, 3), None);
    }
}

#[test]
fn distance_and_exact_arrival_handle_large_valid_coordinates_without_wrapping() {
    assert_eq!(
        Cell { x: 0, y: 0 }.distance(Cell {
            x: u32::MAX,
            y: u32::MAX
        }),
        8_589_934_590
    );
    let (mut scenario, population, mut space) = parts(&MobileScenario::short_journey());
    scenario.grazers[0].reserve_units = u32::MAX;
    scenario.grazers[0].capacity_units = u32::MAX;
    scenario.patches[0].biomass_units = 1;
    space.bounds.width_cells = u32::MAX;
    space.bounds.height_cells = u32::MAX;
    space.grazers[0].cell = Cell {
        x: u32::MAX - 2,
        y: u32::MAX - 2,
    };
    space.grazers[0].motion.max_cells_per_tick = u32::MAX;
    space.patches[0].cell = Cell {
        x: u32::MAX - 1,
        y: u32::MAX - 1,
    };
    let mut world =
        CourseWorld::new_mobile(MobileScenario::new(scenario, population, space.clone())).unwrap();
    world.step();
    let state = world.mobile_snapshot().unwrap();
    assert_eq!(state.grazers[0].cell, space.patches[0].cell);
    assert_eq!(state.ledger.travel_cells, 2);
    assert_eq!(state.base.grazers[0].reserve_units, u32::MAX - 2);
}

#[test]
fn invalid_mobile_inputs_and_mode_switches_are_atomic() {
    let initial = MobileScenario::short_journey();
    let (scenario, population, space) = parts(&initial);
    let cases = vec![
        (
            {
                let mut s = space.clone();
                s.bounds.width_cells = 0;
                s
            },
            MobileError::InvalidBounds,
        ),
        (
            {
                let mut s = space.clone();
                s.grazers.clear();
                s
            },
            MobileError::MissingGrazerPlacement(SimId(1)),
        ),
        (
            {
                let mut s = space.clone();
                s.grazers.push(s.grazers[0]);
                s
            },
            MobileError::DuplicateGrazerPlacement(SimId(1)),
        ),
        (
            {
                let mut s = space.clone();
                s.grazers[0].id = SimId(9);
                s
            },
            MobileError::UnexpectedGrazerPlacement(SimId(9)),
        ),
        (
            {
                let mut s = space.clone();
                s.patches.clear();
                s
            },
            MobileError::MissingPatchPlacement(SimId(100)),
        ),
        (
            {
                let mut s = space.clone();
                s.patches.push(s.patches[0]);
                s
            },
            MobileError::DuplicatePatchPlacement(SimId(100)),
        ),
        (
            {
                let mut s = space.clone();
                s.patches[0].id = SimId(9);
                s
            },
            MobileError::UnexpectedPatchPlacement(SimId(9)),
        ),
        (
            {
                let mut s = space.clone();
                s.grazers[0].cell.x = 4;
                s
            },
            MobileError::OutOfBounds(SimId(1)),
        ),
        (
            {
                let mut s = space.clone();
                s.grazers[0].motion.travel_units_per_cell = 0;
                s
            },
            MobileError::ZeroTravelCost(SimId(1)),
        ),
        (
            {
                let mut s = space.clone();
                s.newborn_motion.travel_units_per_cell = 0;
                s
            },
            MobileError::ZeroNewbornTravelCost,
        ),
    ];
    let mut world = CourseWorld::new_mobile(initial.clone()).unwrap();
    world.step();
    let before = world.mobile_snapshot();
    for (bad_space, error) in cases {
        let bad = MobileScenario::new(scenario.clone(), population.clone(), bad_space);
        assert_eq!(CourseWorld::new_mobile(bad.clone()).err(), Some(error));
        assert_eq!(world.reset_with_mobile(bad), Err(error));
        assert_eq!(world.mobile_snapshot(), before);
    }
    let mut bad_scenario = scenario.clone();
    bad_scenario.grazers[0].feeding_site = Some(SimId(100));
    assert_eq!(
        world.reset_with_mobile(MobileScenario::new(bad_scenario, population.clone(), space)),
        Err(MobileError::AuthoredContact(SimId(1)))
    );
    assert_eq!(world.mobile_snapshot(), before);
    world.reset();
    assert_eq!(world.mobile_snapshot().unwrap().run, 2);
    assert_eq!(world.mobile_snapshot().unwrap().tick, 0);
    assert_eq!(world.mobile_snapshot().unwrap().initial, initial);
    world.reset_with_population(scenario, population).unwrap();
    assert!(world.mobile_snapshot().is_none());
    assert_eq!(world.snapshot().run, 3);
    world.reset();
    assert_eq!(world.snapshot().run, 4);
    assert!(world.mobile_snapshot().is_none());
    world.reset_with(Scenario::limited_supply()).unwrap();
    assert!(world.population_snapshot().is_none());
    assert!(world.mobile_snapshot().is_none());
    world.reset_with_mobile(MobileScenario::meadow()).unwrap();
    assert_eq!(world.mobile_snapshot().unwrap().run, 6);
}

#[test]
fn empty_mobile_world_is_valid_but_two_patches_cannot_occupy_one_cell() {
    let (mut scenario, mut population, mut space) = parts(&MobileScenario::short_journey());
    scenario.grazers.clear();
    population.founders.clear();
    space.grazers.clear();
    let mut world = CourseWorld::new_mobile(MobileScenario::new(
        scenario.clone(),
        population.clone(),
        space.clone(),
    ))
    .unwrap();
    world.step();
    assert!(world.mobile_snapshot().unwrap().grazers.is_empty());
    assert_eq!(
        world
            .mobile_snapshot()
            .unwrap()
            .history
            .travelled_cells_between(1, 1),
        Some(0)
    );
    scenario.patches.push(PatchSeed {
        id: SimId(101),
        ..scenario.patches[0].clone()
    });
    space.patches.push(PatchPlacement {
        id: SimId(101),
        ..space.patches[0]
    });
    assert_eq!(
        CourseWorld::new_mobile(MobileScenario::new(scenario, population, space)).err(),
        Some(MobileError::SharedPatchCell(Cell { x: 2, y: 0 }))
    );
}
